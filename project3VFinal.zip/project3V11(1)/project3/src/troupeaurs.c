# ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "troupeaurs.h"     
#include<gtk/gtk.h>

enum{
	EIDENTIFIANT,
	ESEXE,
	EJOUR,
	EMOIS,
	EANNEE,
	ETYPE,
	COLUMNS,
};

void ajouter(troupeau t){
	FILE *f;	
	f=fopen("troupeauxrs.txt","a+"); 
	if(f!=NULL){	
		fprintf(f,"%s %s %d %d %d %s \n", t.identifiant, t.sexe, t.jour, t.mois, t.annee, t.type);
	}
	fclose(f);
}

int veriftroupeau(troupeau t){
	FILE *f;
	int v=0; 
	char id[20];
	char s[10];
	int j,m,a;
        char ty[10];	
	f=fopen("troupeauxrs.txt","r+");
	if(f!=NULL){
		while(v==0 || (fscanf(f, "%s %s %d %d %d %s \n",id ,s, &j, &m, &a, ty) != EOF)){
			if(strcmp(id,t.identifiant)==0){
				v=1;
				break;
			}
		}
	}
	fclose(f);
	return v;
}

void modifier(troupeau T){
	troupeau t;
	FILE * F=NULL,* f=NULL;
	f=fopen("troupeauxrs.txt","r");
 	F=fopen("troupeauxrs1.txt","w");
	if (f!=NULL){
		while(fscanf(f,"%s %s %d %d %d %s",t.identifiant, t.sexe, &t.jour, &t.mois, &t.annee, t.type)!=EOF){
			if (F!=NULL){
				if (strcmp(T.identifiant,t.identifiant)!=0){
					fprintf(F,"%s %s %d %d %d %s \n",t.identifiant, t.sexe, t.jour, t.mois, t.annee, t.type);
				}
				else{
                    			fprintf(F,"%s %s %d %d %d %s \n",T.identifiant, T.sexe, T.jour, T.mois, T.annee,T.type);
                		}
			}
		}
	}
	fclose(f);
	fclose(F);
	remove("troupeauxrs.txt");
	rename("troupeauxrs1.txt","troupeauxrs.txt");
}

troupeau chercher(char r[20]){
	FILE *f; 
	troupeau T;
	char id[20];
	char s[10];
	int j,m,a;
        char ty[10];	
	f=fopen("troupeauxrs.txt","a+");
	if(f!=NULL){
		while(fscanf(f, "%s %s %d %d %d %s ",id ,s, &j, &m, &a, ty) != EOF){
			if(strcmp(id,T.identifiant)==0){
				break;
			}
		}
	}
	fclose(f);
	strcpy(T.identifiant,id);
	strcpy(T.sexe,s);
	T.jour=j;
	T.mois=m;
	T.annee=a;
	strcpy(T.type,ty);
	return T;
}

void affichertroupeau(GtkWidget *treeview, char ch[]){
	troupeau t;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	gtk_list_store_clear(treeview);
	FILE *f = NULL;
	char J[20],M[20],A[20];
	store = gtk_tree_view_get_model(treeview);
	if (store == NULL)

	{
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("identifiant", renderer, "text", EIDENTIFIANT, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("sexe", renderer, "text", ESEXE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("jour de naissance", renderer, "text", EJOUR, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("mois de naissance", renderer, "text", EMOIS, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("annee de naissance", renderer, "text", EANNEE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("type", renderer, "text", ETYPE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

	}

	store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f = fopen(ch, "r");
	if (f == NULL){
		return;
	}
	else
	{
		while(fscanf(f, "%s %s %s %s %s %s \n", t.identifiant ,t.sexe, J, M, A, t.type) != EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store, &iter, EIDENTIFIANT, t.identifiant, ESEXE, t.sexe, EJOUR, J, EMOIS, M, EANNEE, A, ETYPE,  t.type, -1);
		}
		gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
		g_object_unref(store);
	}
	fclose(f);
}


void supprimertroupeau(troupeau t){
	FILE *f=NULL;
	FILE *F=NULL;
	troupeau T;
	f=fopen("troupeauxrs.txt","r");
 	F=fopen("troupeau1.txt","w");
	if(f==NULL || F==NULL)
		return;
	else{
		while(fscanf(f,"%s %s %d %d %d %s \n",T.identifiant, T.sexe, &T.jour, &T.mois, &T.annee, T.type)!=EOF){
				if(strcmp(T.identifiant,t.identifiant)!=0){
				fprintf(F,"%s %s %d %d %d %s \n",t.identifiant,t.sexe, t.jour, t.mois, t.annee, t.type);
				}
		}
	fclose(f);
	fclose(F);
	remove("troupeauxrs.txt");
	rename("troupeau1.txt","troupeauxrs.txt");
	}
}

int nombrebrebi(){
	int ib=0;
	FILE *F;    	
	FILE *f;	      
	char ln[20];	
	char identifiant[20];
	char id[20];
	char s[10];
	int j,m,a;
        char ty;
	strcpy(ln,"brebi");	
	F=fopen("nombre.txt","a+");
	f=fopen("troupeauxrs.txt","a+");
	if(f!=NULL){
		while(fscanf(f, "%s %s %d %d %d %s ",id ,s, &j, &m, &a, ty) != EOF){
			if(strcmp(id,ln)==0){
				ib++;
			}
		}
	}
	fclose(f);	
	fprintf(F,"%d\n",ib);

	fclose(F);
	return ib;
}

int nombreveau(){
	int iv=0;   	
	FILE *f;	      
	char ln[20];	
	char identifiant[20];
	char id[20];
	char s[10];
	int j,m,a;
        char ty;
	strcpy(ln,"veau");
	f=fopen("troupeauxrs.txt","a+");
	if(f!=NULL){
		while(fscanf(f, "%s %s %d %d %d %s ",id ,s, &j, &m, &a, ty) != EOF){
			if(strcmp(id,ln)==0){
				iv++;
			}
		}
	}
	fclose(f);	
	return iv;
}
