#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "client.h"

enum
{

    CIN,
    NOM,
    PRENOM,
    NATIONALITE,
    SEXE,
    PRIX,
    COLUMNS
};

//Definition des fonctions
/*---------------------------/CONTROLE-SAISIE/---------------------------*/
//Verification du CIN : 0 -> cin erroné | 1 -> cin ok
//Verification de l'existance de client : 1 -> existe / 0 -> non
int verifClient(char cin[], char fich[])
{
    CLIENT c;
    int test = 0;
    FILE *f1;
    f1 = fopen(fich, "r");
    if (f1 != NULL)
    {
        while (fscanf(f1, "%s %s %s %s %s  \n", c.nom, c.prenom,c.cin,c.nationalite,c.sexe) != EOF)
        {
            if ((strcmp(cin, c.cin) == 0))
            {
                test = 1;
            }
        }
        fclose(f1);
        return test;
    }
}


/*---------------------------/C-R-U-D/---------------------------*/
/*---------------------------/TACHE1/---------------------------*/
//Ajout d'un client 
void ajoutClient(CLIENT c, char fich[])
{
    FILE *f;
    f = fopen(fich, "a+");
    if (f != NULL)
    {
        fprintf(f, "%s %s %s %s %s  \n", c.nom, c.prenom,c.cin,c.nationalite,c.sexe);
        fclose(f);
    }
}

//Modification des informations
void modifierclient(CLIENT a,char cin[])
{
    CLIENT c;
    FILE * f1,* f;
    f=fopen("client.txt","r"); 
    f1=fopen("temp.txt","w"); 
    if (f!=NULL)
    {
        while (fscanf(f,"%s %s %s %s %s  \n", c.nom, c.prenom,c.cin,c.nationalite,c.sexe)!=EOF)  
        {     
            if (f1!=NULL) 
            {	
                if (strcmp(cin,c.cin)!=0)
                {
                    fprintf(f1,"%s %s %s %s %s  \n", c.nom, c.prenom,c.cin,c.nationalite,c.sexe);
                }  
                else
                {
                    fprintf(f1,"%s %s %s %s %s  \n", a.nom, a.prenom,a.cin,a.nationalite,a.sexe);
                }
                    
            }       
   
        }           	
    }
    fclose(f);
    fclose(f1);
    remove("client.txt");
    rename("temp.txt","client.txt");
}


//Suppression d'un client
void supprimer(char cin[])
{
CLIENT u;
    FILE *f;
    FILE *f2;
    f = fopen("client.txt", "r");
    f2 = fopen("tmp.txt", "w");
    if ((f == NULL) || (f2 == NULL))
    return;
else{
        while (fscanf(f, "%s %s %s %s %s  \n", u.nom, u.prenom,u.cin,u.nationalite,u.sexe) != EOF)//enregistrement dans u
        {
            if (strcmp(cin, u.cin)!=0 ) 

                fprintf(f2, "%s %s %s %s %s  \n", u.nom, u.prenom,u.cin,u.nationalite,u.sexe);
           }
}
    fclose(f);
    fclose(f2);
    remove("client.txt");
    rename("tmp.txt", "client.txt");

}
//Recherche des informations d'un client
void rechClient(GtkWidget *TreeviewAfficher)
{
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	CLIENT u;
	store = NULL;
	FILE *f2;
	store = gtk_tree_view_get_model(TreeviewAfficher);
	if (store == NULL)
	{
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text", NOM, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(TreeviewAfficher), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text", PRENOM, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(TreeviewAfficher), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("cin", renderer, "text", CIN, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(TreeviewAfficher), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nationalite", renderer, "text", NATIONALITE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(TreeviewAfficher), column);



		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("sexe", renderer, "text", SEXE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(TreeviewAfficher), column);
	}

	store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f2 = fopen("temp.txt", "r");
	if (f2 == NULL)
	{
		return;
	}
	else
	{
		f2 = fopen("temp.txt", "a+");
		while (fscanf(f2, "%s %s %s %s %s   \n", u.nom, u.prenom,u.cin,u.nationalite,u.sexe) != EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store, &iter, CIN, u.cin,   NOM, u.nom, PRENOM, u.prenom,  NATIONALITE, u.nationalite, SEXE, u.sexe, -1);
		}
		fclose(f2);
		gtk_tree_view_set_model(GTK_TREE_VIEW(TreeviewAfficher), GTK_TREE_MODEL(store));
		g_object_unref(store);
	}
}
//Affichage
void affClient(GtkWidget *treeview, char fich[])
{

    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;
    CLIENT u;
    gtk_list_store_clear(treeview);
    FILE *f = NULL;
    store = gtk_tree_view_get_model(treeview);
    if (store == NULL)
    {
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" cin", renderer, "text", CIN, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);


        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" NOM", renderer, "text", NOM, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" PRENOM", renderer, "text", PRENOM, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" Nationalite", renderer, "text", NATIONALITE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);


        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" SEXE", renderer, "text", SEXE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    }
    store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
    f = fopen(fich, "r");
    if (f == NULL)
    {
        return;
    }
    else
    {
        while (fscanf(f, "%s %s %s %s %s   \n", u.nom, u.prenom,u.cin,u.nationalite,u.sexe) != EOF)
        {
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter, CIN, u.cin,   NOM, u.nom, PRENOM, u.prenom,  NATIONALITE, u.nationalite, SEXE, u.sexe, -1);
        }
        gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
        g_object_unref(store);
    }
    fclose(f);
}
//Ajout Du CLient Fidele
void ajouterclientfid(CLIENT c, char fich[])
{
    FILE *f;
    f = fopen(fich, "a");
    if (f != NULL)
    {
        fprintf(f, "%s %s   \n", c.cin, c.prix);
        fclose(f);
    }
}
//Affichage Du CLient Fidele
void affClientfid(GtkWidget *treeview, char fich[])
{

    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;
    CLIENT u;
    gtk_list_store_clear(treeview);
    FILE *f = NULL;
    store = gtk_tree_view_get_model(treeview);
    if (store == NULL)
    {
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" cin", renderer, "text", CIN, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);


        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" prix", renderer, "text", PRIX, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);


    }
    store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
    f = fopen(fich, "r");
    if (f == NULL)
    {
        return;
    }
    else
    {
        while (fscanf(f, "%s %s    \n", u.cin, u.prix) != EOF)
        {
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter, CIN, u.cin,   PRIX, u.prix, -1);
        }
        gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
        g_object_unref(store);
    }
    fclose(f);
}
CLIENT recheClient(char cin[])
{

FILE *F;
  CLIENT Q;
  CLIENT A;
  
F = fopen ("client.txt", "r");


  if (F!=NULL)
{
  while (fscanf (F, "%s %s %s %s %s   \n", Q.nom, Q.prenom, Q.cin, Q.nationalite , Q.sexe) )
{
    if (strcmp ( Q.cin, cin) == 0)
        {
        strcpy( A.nom, Q.nom);
        strcpy( A.prenom, Q.prenom);
        strcpy( A.cin, Q.cin);
        strcpy( A.nationalite, Q.nationalite);
	strcpy( A.sexe, Q.sexe);
        return (A);
        }

  }
    
}
return (A);
  fclose (F);
}

