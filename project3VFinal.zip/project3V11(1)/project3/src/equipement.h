#include <stdlib.h>
#include <stdio.h>

//Declaration de structure Equipement
struct equipement
{
    char ref[20];
    char nom[20];
    int quant;
    char type[20];
    char marq[20];
};
typedef struct equipement Equi;

//les foctions à utiliser
void ajouter_e(Equi E);
void modifier_e(Equi M);
void supprimer_e(char ref[20]);
void consulter_e();
Equi rechercher_e(char ref[20]);
void afficher_e();
int verifier_refe(char ref[20]);
//cette fonction est pour la 2éme tache ,La marque ayant le maximum de capteurs défectueux
void capteur_defect();
