#include <stdlib.h>
#include <stdio.h>
#include <gtk/gtk.h>

//Declaration de structure donnee et capteur
struct donnee
{
	char ref[20];
	char marque[20];
	int jour;
	int mois;
	int annee;
	int valeur;
    
    
};
typedef struct donnee don;

struct capteur
{
	char ref[20];
	char type[20];
	char emp[20];
	char marq[20];
	int etat;
  
};
typedef struct capteur cap;

void ajouter_donnee(don d);
//void ajouter_alerte(don d);
void consulter_donnee(GtkWidget *treeviewListeDonnees);
void supprimer_donneeCapteur(char ref[20]);
//les foctions à utiliser
void ajouter_capteur(cap c);
void modifier_capteur(cap ca);
void supprimer_capteur(char ref[20]);
void consulter_capteur(GtkWidget *treeviewListeCapteurs);
cap rechercher_capteur(char ref[20]);
void afficher_capteur();
int verifier_ref(char ref[20]);

