#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <gtk/gtk.h>
#include "gestionUtils.h"
#include "gestionPl.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteur.h"
#include "equipement.h"
#include "troupeaurs.h"
#include "client.h"
/*#######################/GESTION DES UTILISATEURS/#######################*/
int checkaff_wadm[2] = {0, 0};
int sexeaj_wadm, sexemod_wadm, rolemod_wadm, rolesup_wadm;
int sexeaj_wemp, sexemod_wemp, rolemod_wemp, rolesup_wemp;
int roleabs_wadm, roletabs_wadm, presabs_wadm;
int varaj, varmod;
void on_buttoncnx_clicked(GtkButton *button,
                          gpointer user_data)
{
    char fich[20], cinrole[20];
    strcpy(fich, "users.txt");
    UTILISATEUR a;
    FILE *f1;
    int test = 0;
    GtkWidget *login, *mdp;
    GtkWidget *EspaceAdmin, *InterEmp, *Authentification;
    GtkWidget *output;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    login = lookup_widget(button, "entryLogin");
    mdp = lookup_widget(button, "entryMdp");
    output = lookup_widget(button, "hwlabelauth");

    f1 = fopen(fich, "r");
    if (f1 != NULL)
    {
        while (fscanf(f1, "%s %s %s %s %s %s %s %s \n", a.log.cin, a.log.pw, a.nom, a.prenom, a.dateNaiss, a.numTel, a.sexe, a.role) != EOF)
        {
            if ((strcmp(a.log.cin, gtk_entry_get_text(GTK_ENTRY(login))) == 0) && (strcmp(a.log.pw, gtk_entry_get_text(GTK_ENTRY(mdp))) == 0))
            {
                test = 1;
            }
        }
        fclose(f1);
    }
    if (!test)
    {
        sprintf(msg, "Login ou mot de passe incorrect !");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else
    {
        f1 = fopen(fich, "r");
        strcpy(cinrole, gtk_entry_get_text(GTK_ENTRY(login)));
        if (f1 != NULL)
        {
            while (fscanf(f1, "%s %s %s %s %s %s %s %s \n", a.log.cin, a.log.pw, a.nom, a.prenom, a.dateNaiss, a.numTel, a.sexe, a.role) != EOF)
            {
                if ((strcmp(cinrole, a.log.cin) == 0))
                {
                    if ((strcmp(a.role, "Admin") == 0))
                    {
                        Authentification = lookup_widget(button, "Authentification");
                        gtk_widget_destroy(Authentification);
                        EspaceAdmin = lookup_widget(button, "EspaceAdmin");
                        EspaceAdmin = create_EspaceAdmin();
                        gtk_window_set_position(GTK_WINDOW(EspaceAdmin), GTK_WIN_POS_CENTER_ALWAYS);
                        gtk_widget_show(EspaceAdmin);
                    }
                    else if ((strcmp(a.role, "Employe")) == 0)
                    {
                        Authentification = lookup_widget(button, "Authentification");
                        gtk_widget_destroy(Authentification);
                        InterEmp = lookup_widget(button, "InterEmp");
                        InterEmp = create_InterEmp();
                        gtk_window_set_position(GTK_WINDOW(InterEmp), GTK_WIN_POS_CENTER_ALWAYS);
                        gtk_widget_show(InterEmp);
                    }
                }
            }
        }
        fclose(f1);
    }
}

void on_buttonquit_clicked(GtkButton *button,
                           gpointer user_data)
{
    gtk_main_quit();
}

void on_buttonaj_wadm_clicked(GtkButton *button,
                              gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *ajout_wadm;

    gestionUtils = lookup_widget(button, "gestionUtils");
    gtk_widget_destroy(gestionUtils);

    ajout_wadm = lookup_widget(button, "ajout_wadm");
    ajout_wadm = create_ajout_wadm();
    gtk_window_set_position(GTK_WINDOW(ajout_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(ajout_wadm);
}

void on_buttonmod_wadm_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *modif_wadm;

    gestionUtils = lookup_widget(button, "gestionUtils");
    gtk_widget_destroy(gestionUtils);

    modif_wadm = lookup_widget(button, "modif_wadm");
    modif_wadm = create_modif_wadm();
    gtk_window_set_position(GTK_WINDOW(modif_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(modif_wadm);
}

void on_buttonrech_wadm_clicked(GtkButton *button,
                                gpointer user_data)
{
    char fich[20], rech[20], cin[20];
    strcpy(fich, "users.txt");
    strcpy(rech, "rech.txt");
    GtkWidget *cinrech, *output, *aff_wadm, *treeview;
    UTILISATEUR u;
    FILE *f = NULL, *f1 = NULL;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    aff_wadm = lookup_widget(button, "aff_wadm");
    cinrech = lookup_widget(button, "rech_wadm");
    output = lookup_widget(button, "outputrech_wadm");

    strcpy(cin, gtk_entry_get_text(GTK_ENTRY(cinrech)));
    if (!verifCin(cin))
    {
        sprintf(msg, "Le CIN doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else if (!verifUtils(cin, fich))
    {

        sprintf(msg, "L'utilisateur n'existe pas!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        gtk_label_set_text(GTK_LABEL(output), "");
        f = fopen(fich, "r");
        f1 = fopen(rech, "w");
        if ((f != NULL) && (f1 != NULL))
        {
            while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
            {
                if (strcmp(cin, u.log.cin) == 0)
                {
                    fprintf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
                }
            }
        }
        fclose(f1);
        fclose(f);
        gtk_window_set_position(GTK_WINDOW(aff_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(aff_wadm);
        treeview = lookup_widget(aff_wadm, "treeviewaff_wadm");
        affUtils(treeview, rech);
        remove("rech.txt");
    }
}

void on_buttondcnx_wadm_clicked(GtkButton *button,
                                gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *Authentification;

    gestionUtils = lookup_widget(button, "gestionUtils");
    gtk_widget_destroy(gestionUtils);

    Authentification = lookup_widget(button, "Authentification");
    Authentification = create_Authentification();
    gtk_window_set_position(GTK_WINDOW(Authentification), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(Authentification);
}

void on_buttonvalaj_wadm_clicked(GtkButton *button,
                                 gpointer user_data)
{
    char fich[20];
    strcpy(fich, "users.txt");
    UTILISATEUR u;
    GtkWidget *cin, *nom, *prenom, *pw, *numtel, *jour, *mois, *annee, *role;
    GtkWidget *output_ajout;
    GtkWidget *ajout_wadm, *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    output_ajout = lookup_widget(button, "outputaj_wadm");

    cin = lookup_widget(button, "cinaj_wadm");
    nom = lookup_widget(button, "nomaj_wadm");
    prenom = lookup_widget(button, "pnomaj_wadm");
    pw = lookup_widget(button, "pwaj_wadm");
    numtel = lookup_widget(button, "numtelaj_wadm");
    role = lookup_widget(button, "cbroleaj_wadm");
    jour = lookup_widget(button, "spinjaj_wadm");
    mois = lookup_widget(button, "spinmaj_wadm");
    annee = lookup_widget(button, "spinaaj_wadm");

    if (!verifCin(gtk_entry_get_text(GTK_ENTRY(cin))))
    {
        sprintf(msg, "Le CIN doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (verifUtils(gtk_entry_get_text(GTK_ENTRY(cin)), fich))
    {
        sprintf(msg, "L'utilisateur existe déjà!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (verifNum(gtk_entry_get_text(GTK_ENTRY(nom))))
    {
        sprintf(msg, "Le nom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if ((verifNum(gtk_entry_get_text(GTK_ENTRY(prenom)))))
    {
        sprintf(msg, "Le prénom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (!verifCin(gtk_entry_get_text(GTK_ENTRY(numtel))))
    {
        sprintf(msg, "Le numero telephonique doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        strcpy(u.log.cin, gtk_entry_get_text(GTK_ENTRY(cin)));
        strcpy(u.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
        strcpy(u.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
        strcpy(u.log.pw, gtk_entry_get_text(GTK_ENTRY(pw)));
        strcpy(u.numTel, gtk_entry_get_text(GTK_ENTRY(numtel)));
        strcpy(u.role, gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)));

        suppEspaces(u.nom);
        suppEspaces(u.prenom);

        u.date.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
        u.date.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
        u.date.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
        strcpy(u.sexe, "Homme");
        if (sexeaj_wadm == 1)
        {
            strcpy(u.sexe, "Homme");
        }
        else if (sexeaj_wadm == 2)
        {
            strcpy(u.sexe, "Femme");
        }
        ajoutUtils(u, fich);
        ajout_wadm = lookup_widget(button, "ajout_wadm");
        //gtk_widget_destroy(ajout_wadm);
        succ_wadm = lookup_widget(button, "succ_wadm");
        succ_wadm = create_succ_wadm();
        gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Ajout");
        gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(succ_wadm);
        msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
        sprintf(msg, "Utilisateur ajouté avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
    }
}

void on_buttonretaj_wadm_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *ajout_wadm;

    ajout_wadm = lookup_widget(button, "ajout_wadm");
    gtk_widget_destroy(ajout_wadm);

    gestionUtils = lookup_widget(button, "gestionUtils");
    gestionUtils = create_gestionUtils();
    gtk_window_set_position(GTK_WINDOW(gestionUtils), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionUtils);
}

void on_buttonvalmod_wadm_clicked(GtkButton *button,
                                  gpointer user_data)
{
    char fich[20];
    strcpy(fich, "users.txt");
    UTILISATEUR u;
    GtkWidget *cin, *nom, *prenom, *pw, *numtel, *jour, *mois, *annee, *role;
    GtkWidget *ad, *admin, *emp, *employe, *ouv, *ouvrier;
    GtkWidget *output_modif;
    GtkWidget *modif_wadm, *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    modif_wadm = lookup_widget(button, "modif_wadm");
    output_modif = lookup_widget(button, "outputmod_wadm");

    nom = lookup_widget(button, "nommod_wadm");
    prenom = lookup_widget(button, "prnommod_wadm");
    pw = lookup_widget(button, "pwmod_wadm");
    numtel = lookup_widget(button, "numtelmod_wadm");
    role = lookup_widget(button, "cbrolemod_wadm");
    jour = lookup_widget(button, "spinjmod_wadm");
    mois = lookup_widget(button, "spinmmod_wadm");
    annee = lookup_widget(button, "spinamod_wadm");
    ad = lookup_widget(button, "lsadms_wadm");
    emp = lookup_widget(button, "lsemp_wadm");
    ouv = lookup_widget(button, "lsouv_wadm");
    admin = lookup_widget(button, "cbadmmodif_wadm");
    employe = lookup_widget(button, "cbempmodif_wadm");
    ouvrier = lookup_widget(button, "cbouvmodif_wadm");

    if (verifNum(gtk_entry_get_text(GTK_ENTRY(nom))))
    {
        sprintf(msg, "Le nom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else if ((verifNum(gtk_entry_get_text(GTK_ENTRY(prenom)))))
    {
        sprintf(msg, "Le prénom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else if (!verifCin(gtk_entry_get_text(GTK_ENTRY(numtel))))
    {
        sprintf(msg, "Le numero telephonique doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ad)))
        {
            strcpy(u.log.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(admin)));
        }
        else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
        {
            strcpy(u.log.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
        }
        else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
        {
            strcpy(u.log.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
        }
        strcpy(u.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
        strcpy(u.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
        strcpy(u.log.pw, gtk_entry_get_text(GTK_ENTRY(pw)));
        strcpy(u.numTel, gtk_entry_get_text(GTK_ENTRY(numtel)));
        strcpy(u.role, gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)));

        suppEspaces(u.nom);
        suppEspaces(u.prenom);

        u.date.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
        u.date.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
        u.date.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
        strcpy(u.sexe, "Homme");
        if (sexemod_wadm == 1)
        {
            strcpy(u.sexe, "Homme");
        }
        else if (sexemod_wadm == 2)
        {
            strcpy(u.sexe, "Femme");
        }
        modifUtils(u, u.log.cin, fich);
        modif_wadm = lookup_widget(button, "modif_wadm");
        //gtk_widget_destroy(modif_wadm);
        succ_wadm = lookup_widget(button, "succ_wadm");
        succ_wadm = create_succ_wadm();
        gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Modification");
        gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(succ_wadm);
        msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
        sprintf(msg, "Modification effectuee avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
    }
}

void on_buttonretmod_wadm_clicked(GtkButton *button,
                                  gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *modif_wadm;

    modif_wadm = lookup_widget(button, "modif_wadm");
    gtk_widget_destroy(modif_wadm);

    gestionUtils = lookup_widget(button, "gestionUtils");
    gestionUtils = create_gestionUtils();
    gtk_window_set_position(GTK_WINDOW(gestionUtils), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionUtils);
}

void on_buttonokmod_wadm_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *nom, *prenom, *pw, *numtel, *role, *jour, *mois, *annee, *admin, *employe, *ouvrier, *homme, *femme;
    GtkWidget *ad, *emp, *ouv;
    GtkWidget *output_modif;
    UTILISATEUR u;
    char fich[20];
    strcpy(fich, "users.txt");

    output_modif = lookup_widget(button, "outputmod_wadm");
    gtk_label_set_text(GTK_LABEL(output_modif), "");
    nom = lookup_widget(button, "nommod_wadm");
    prenom = lookup_widget(button, "prnommod_wadm");
    pw = lookup_widget(button, "pwmod_wadm");
    numtel = lookup_widget(button, "numtelmod_wadm");
    role = lookup_widget(button, "cbrolemod_wadm");
    jour = lookup_widget(button, "spinjmod_wadm");
    mois = lookup_widget(button, "spinmmod_wadm");
    annee = lookup_widget(button, "spinamod_wadm");
    admin = lookup_widget(button, "cbadmmodif_wadm");
    employe = lookup_widget(button, "cbempmodif_wadm");
    ouvrier = lookup_widget(button, "cbouvmodif_wadm");
    homme = lookup_widget(button, "hrmod_wadm");
    femme = lookup_widget(button, "frmod_wadm");
    ad = lookup_widget(button, "lsadms_wadm");
    emp = lookup_widget(button, "lsemp_wadm");
    ouv = lookup_widget(button, "lsouv_wadm");
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ad)))
    {
        u = rechUtils(gtk_combo_box_get_active_text(GTK_COMBO_BOX(admin)), fich);
        gtk_combo_box_set_active(GTK_COMBO_BOX(role), 0);
        gtk_entry_set_text(GTK_ENTRY(nom), u.nom);
        gtk_entry_set_text(GTK_ENTRY(prenom), u.prenom);
        gtk_entry_set_text(GTK_ENTRY(pw), u.log.pw);
        gtk_entry_set_text(GTK_ENTRY(numtel), u.numTel);
        sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour), u.date.jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois), u.date.mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee), u.date.annee);
        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 1);
        }
    }
    else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
    {
        u = rechUtils(gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)), fich);
        gtk_combo_box_set_active(GTK_COMBO_BOX(role), 1);
        gtk_entry_set_text(GTK_ENTRY(nom), u.nom);
        gtk_entry_set_text(GTK_ENTRY(prenom), u.prenom);
        gtk_entry_set_text(GTK_ENTRY(pw), u.log.pw);
        gtk_entry_set_text(GTK_ENTRY(numtel), u.numTel);
        sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour), u.date.jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois), u.date.mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee), u.date.annee);
        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 1);
        }
    }
    else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
    {
        u = rechUtils(gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)), fich);
        gtk_combo_box_set_active(GTK_COMBO_BOX(role), 2);
        gtk_entry_set_text(GTK_ENTRY(nom), u.nom);
        gtk_entry_set_text(GTK_ENTRY(prenom), u.prenom);
        gtk_entry_set_text(GTK_ENTRY(pw), u.log.pw);
        gtk_entry_set_text(GTK_ENTRY(numtel), u.numTel);
        sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour), u.date.jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois), u.date.mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee), u.date.annee);
        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 1);
        }
    }
}
void on_buttonsuppr_wadm_clicked(GtkButton *button,
                                 gpointer user_data)
{
    char fich[20];
    strcpy(fich, "users.txt");
    char cinsup[50];
    UTILISATEUR u;
    GtkWidget *ad, *admin, *emp, *employe, *ouvrier, *ouv;
    GtkWidget *succ_wadm, *msg_succ;

    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    admin = lookup_widget(button, "cbadmmodif_wadm");
    employe = lookup_widget(button, "cbempmodif_wadm");
    ouvrier = lookup_widget(button, "cbouvmodif_wadm");
    ad = lookup_widget(button, "lsadms_wadm");
    emp = lookup_widget(button, "lsemp_wadm");
    ouv = lookup_widget(button, "lsouv_wadm");
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ad)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(admin)));
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
    }
    suppUtils(cinsup, fich);
    succ_wadm = create_succ_wadm();
    gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Suppression");
    gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(succ_wadm);
    msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
    sprintf(msg, "Utilisateur supprimé!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
}

void on_hraj_wadm_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexeaj_wadm = 1;
    }
}

void on_fraj_wadm_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexeaj_wadm = 2;
    }
}
void on_lsouv_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolemod_wadm = 3;
    }
}

void on_lsemp_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolemod_wadm = 2;
    }
}

void on_lsadms_wadm_toggled(GtkToggleButton *togglebutton,
                            gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolemod_wadm = 1;
    }
}

void on_hrmod_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexemod_wadm = 1;
    }
}

void on_frmod_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexemod_wadm = 2;
    }
}

void on_lsadmsup_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolesup_wadm = 1;
    }
}

void on_lsempsup_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolesup_wadm = 2;
    }
}

void on_lsouvsup_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolesup_wadm = 3;
    }
}

void on_buttonaff_wadm_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *aff_wadm;

    gestionUtils = lookup_widget(button, "gestionUtils");
    gtk_widget_destroy(gestionUtils);

    aff_wadm = lookup_widget(button, "aff_wadm");
    aff_wadm = create_aff_wadm();
    gtk_window_set_position(GTK_WINDOW(aff_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(aff_wadm);
}

void on_buttonret_wadm_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *EspaceAdmin;

    gestionUtils = lookup_widget(button, "gestionUtils");
    gtk_widget_destroy(gestionUtils);

    EspaceAdmin = lookup_widget(button, "EspaceAdmin");
    EspaceAdmin = create_EspaceAdmin();
    gtk_window_set_position(GTK_WINDOW(EspaceAdmin), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(EspaceAdmin);
}

void on_treeviewaff_wadm_row_activated(GtkTreeView *treeview,
                                       GtkTreePath *path,
                                       GtkTreeViewColumn *column,
                                       gpointer user_data)
{
    GtkTreeIter iter;
    GtkWidget *aff_wadm, *modif_wadm;
    gchar *cin, *pw, *nom, *prenom, *dateNaiss, *numtel, *sexe, *role;
    GtkWidget *CIN, *PW, *NOM, *PRENOM, *JOUR, *MOIS, *ANNEE, *NUMTEL, *HOMME, *FEMME, *ROLE, *AD, *EMP, *OUV;
    GtkWidget *CBAD, *CBEMP, *CBOUV;
    UTILISATEUR u;
    int ligne;
    char fich[50];
    FILE *f = NULL, *fa = NULL, *fe = NULL, *fo = NULL;
    FILE *fae = NULL, *fao = NULL, *feo = NULL;

    f = fopen("users.txt", "r");
    fa = fopen("admins.txt", "w");
    fe = fopen("employes.txt", "w");
    fo = fopen("ouvriers.txt", "w");

    if ((f != NULL) && (fa != NULL) && (fe != NULL) && (fo != NULL))
    {
        while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            if (strcmp(u.role, "Admin") == 0)
            {
                fprintf(fa, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            if (strcmp(u.role, "Employe") == 0)
            {
                fprintf(fe, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            if (strcmp(u.role, "Ouvrier") == 0)
            {
                fprintf(fo, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
        }
    }
    fclose(f);
    fclose(fa);
    fclose(fe);
    fclose(fo);

    aff_wadm = lookup_widget(treeview, "aff_wadm");
    GtkTreeModel *model = gtk_tree_view_get_model(treeview);
    if (gtk_tree_model_get_iter(model, &iter, path))
    {
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &cin, 1, &pw, 2, &nom, 3, &prenom, 4, &dateNaiss, 5, &numtel, 6, &sexe, 7, &role, -1);
        strcpy(u.log.cin, cin);
        strcpy(u.log.pw, pw);
        strcpy(u.nom, nom);
        strcpy(u.prenom, prenom);
        strcpy(u.dateNaiss, dateNaiss);
        strcpy(u.numTel, numtel);
        strcpy(u.sexe, sexe);
        strcpy(u.role, role);
        sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);

        modif_wadm = create_modif_wadm();
        gtk_widget_hide(aff_wadm);
        gtk_window_set_position(GTK_WINDOW(modif_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(modif_wadm);

        NOM = lookup_widget(modif_wadm, "nommod_wadm");
        PRENOM = lookup_widget(modif_wadm, "prnommod_wadm");
        ROLE = lookup_widget(modif_wadm, "cbrolemod_wadm");
        JOUR = lookup_widget(modif_wadm, "spinjmod_wadm");
        MOIS = lookup_widget(modif_wadm, "spinmmod_wadm");
        ANNEE = lookup_widget(modif_wadm, "spinamod_wadm");
        NUMTEL = lookup_widget(modif_wadm, "numtelmod_wadm");
        PW = lookup_widget(modif_wadm, "pwmod_wadm");
        HOMME = lookup_widget(modif_wadm, "hrmod_wadm");
        FEMME = lookup_widget(modif_wadm, "frmod_wadm");
        AD = lookup_widget(modif_wadm, "lsadms_wadm");
        EMP = lookup_widget(modif_wadm, "lsemp_wadm");
        OUV = lookup_widget(modif_wadm, "lsouv_wadm");
        CBAD = lookup_widget(modif_wadm, "cbadmmodif_wadm");
        CBEMP = lookup_widget(modif_wadm, "cbempmodif_wadm");
        CBOUV = lookup_widget(modif_wadm, "cbouvmodif_wadm");

        gtk_entry_set_text(GTK_ENTRY(NOM), nom);
        gtk_entry_set_text(GTK_ENTRY(PRENOM), prenom);
        gtk_entry_set_text(GTK_ENTRY(CIN), cin);
        gtk_entry_set_text(GTK_ENTRY(PW), pw);
        gtk_entry_set_text(GTK_ENTRY(NUMTEL), numtel);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(JOUR), u.date.jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(MOIS), u.date.mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(ANNEE), u.date.annee);
        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 1);
        }
        if ((strcmp(u.role, "Admin") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(AD), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(EMP), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(OUV), 0);
            gtk_combo_box_set_active(GTK_COMBO_BOX(ROLE), 0);
            ligne = rechLigne(u.log.cin, "admins.txt");
            ligne -= 1;
            gtk_combo_box_set_active(GTK_COMBO_BOX(CBAD), ligne);
            ligne = 0;
        }
        else if ((strcmp(u.role, "Employe") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(AD), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(EMP), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(OUV), 0);
            gtk_combo_box_set_active(GTK_COMBO_BOX(ROLE), 1);
            ligne = rechLigne(u.log.cin, "employes.txt");
            ligne -= 1;
            gtk_combo_box_set_active(GTK_COMBO_BOX(CBEMP), ligne);
        }
        else if ((strcmp(u.role, "Ouvrier") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(AD), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(EMP), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(OUV), 1);
            gtk_combo_box_set_active(GTK_COMBO_BOX(ROLE), 2);
            ligne = rechLigne(u.log.cin, "ouvriers.txt");
            ligne -= 1;
            gtk_combo_box_set_active(GTK_COMBO_BOX(CBOUV), ligne);
        }
    }
    remove("admins.txt");
    remove("employes.txt");
    remove("ouvriers.txt");
}

void on_buttonafficher_wadm_clicked(GtkButton *button,
                                    gpointer user_data)
{
    GtkWidget *treeview, *gestionUtils, *aff_wadm;
    GtkWidget *ad, *emp, *ouv, *output;
    char fich[20];
    UTILISATEUR u;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    aff_wadm = lookup_widget(button, "aff_wadm");
    ad = lookup_widget(button, "checkadm_wadm");
    emp = lookup_widget(button, "checkemp_wadm");
    ouv = lookup_widget(button, "checkouv_wadm");
    output = lookup_widget(button, "outputrech_wadm");

    FILE *f = NULL, *fa = NULL, *fe = NULL, *fo = NULL;
    FILE *fae = NULL, *fao = NULL, *feo = NULL;
    FILE *vide = NULL;

    f = fopen("users.txt", "r");
    fa = fopen("admins.txt", "w");
    fe = fopen("employes.txt", "w");
    fo = fopen("ouvriers.txt", "w");

    fae = fopen("ademp.txt", "w");
    fao = fopen("adouv.txt", "w");
    feo = fopen("empouv.txt", "w");
    vide = fopen("vide.txt", "w");

    if ((f != NULL) && (fa != NULL) && (fe != NULL) && (fo != NULL))
    {
        while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            if (strcmp(u.role, "Admin") == 0)
            {
                fprintf(fa, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            if (strcmp(u.role, "Employe") == 0)
            {
                fprintf(fe, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            if (strcmp(u.role, "Ouvrier") == 0)
            {
                fprintf(fo, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            if ((strcmp(u.role, "Admin") == 0) || (strcmp(u.role, "Ouvrier") == 0))
            {
                fprintf(fao, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            if ((strcmp(u.role, "Admin") == 0) || (strcmp(u.role, "Employe") == 0))
            {
                fprintf(fae, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            if ((strcmp(u.role, "Ouvrier") == 0) || (strcmp(u.role, "Employe") == 0))
            {
                fprintf(feo, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            if ((strcmp(u.role, "Admin") != 0) && (strcmp(u.role, "Ouvrier") != 0) && (strcmp(u.role, "Employe") != 0))
            {
                fprintf(vide, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
        }
    }
    fclose(f);
    fclose(fa);
    fclose(fe);
    fclose(fo);
    fclose(fae);
    fclose(fao);
    fclose(feo);
    fclose(vide);
    if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ad)) && gtk_toggle_button_get_active(GTK_CHECK_BUTTON(emp)) && gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ouv)))
    {
        gtk_label_set_text(GTK_LABEL(output), "");
        strcpy(fich, "users.txt");
    }
    else if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ad)) && !gtk_toggle_button_get_active(GTK_CHECK_BUTTON(emp)) && !gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ouv)))
    {
        gtk_label_set_text(GTK_LABEL(output), "");
        strcpy(fich, "admins.txt");
    }
    else if (!gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ad)) && gtk_toggle_button_get_active(GTK_CHECK_BUTTON(emp)) && !gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ouv)))
    {
        gtk_label_set_text(GTK_LABEL(output), "");
        strcpy(fich, "employes.txt");
    }
    else if (!gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ad)) && !gtk_toggle_button_get_active(GTK_CHECK_BUTTON(emp)) && gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ouv)))
    {
        gtk_label_set_text(GTK_LABEL(output), "");
        strcpy(fich, "ouvriers.txt");
    }
    else if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ad)) && gtk_toggle_button_get_active(GTK_CHECK_BUTTON(emp)) && !gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ouv)))
    {
        gtk_label_set_text(GTK_LABEL(output), "");
        strcpy(fich, "ademp.txt");
    }
    else if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ad)) && !gtk_toggle_button_get_active(GTK_CHECK_BUTTON(emp)) && gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ouv)))
    {
        gtk_label_set_text(GTK_LABEL(output), "");
        strcpy(fich, "adouv.txt");
    }
    else if (!gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ad)) && gtk_toggle_button_get_active(GTK_CHECK_BUTTON(emp)) && gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ouv)))
    {
        gtk_label_set_text(GTK_LABEL(output), "");
        strcpy(fich, "empouv.txt");
    }
    else
    {
        sprintf(msg, "<- Selectionnez\nau moins un utilisateur!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
        strcpy(fich, "vide.txt");
    }
    //gtk_label_set_text(GTK_LABEL(output), "");
    gtk_window_set_position(GTK_WINDOW(aff_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(aff_wadm);
    treeview = lookup_widget(aff_wadm, "treeviewaff_wadm");
    affUtils(treeview, fich);
    remove("admins.txt");
    remove("employes.txt");
    remove("ouvriers.txt");
    remove("ademp.txt");
    remove("adouv.txt");
    remove("empouv.txt");
    remove("vide.txt");
}

void on_buttonretaff_wadm_clicked(GtkButton *button,
                                  gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *aff_wadm;

    aff_wadm = lookup_widget(button, "aff_wadm");
    gtk_widget_destroy(aff_wadm);

    gestionUtils = lookup_widget(button, "gestionUtils");
    gestionUtils = create_gestionUtils();
    gtk_window_set_position(GTK_WINDOW(gestionUtils), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionUtils);
}

void on_okbuttonsucc_wadm_clicked(GtkButton *button,
                                  gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *succ_wadm;

    succ_wadm = lookup_widget(button, "succ_wadm");
    gtk_widget_destroy(succ_wadm);

    //gestionUtils = lookup_widget(button, "gestionUtils");
    //gestionUtils = create_gestionUtils();
    // gtk_widget_show(gestionUtils);
}

void on_buttondcnx_ea_clicked(GtkButton *button,
                              gpointer user_data)
{
    GtkWidget *EspaceAdmin;
    GtkWidget *Authentification;

    EspaceAdmin = lookup_widget(button, "EspaceAdmin");
    gtk_widget_destroy(EspaceAdmin);

    Authentification = lookup_widget(button, "Authentification");
    Authentification = create_Authentification();
    gtk_window_set_position(GTK_WINDOW(Authentification), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(Authentification);
}

void on_buttongestion_ea_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *EspaceAdmin;
    GtkWidget *gestionUtils;

    EspaceAdmin = lookup_widget(button, "EspaceAdmin");
    gtk_widget_destroy(EspaceAdmin);

    gestionUtils = lookup_widget(button, "gestionUtils");
    gestionUtils = create_gestionUtils();
    gtk_window_set_position(GTK_WINDOW(gestionUtils), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionUtils);
}
void on_buttonemp_ea_clicked(GtkButton *button,
                             gpointer user_data)
{
    GtkWidget *EspaceAdmin;
    GtkWidget *InterEmp;

    EspaceAdmin = lookup_widget(button, "EspaceAdmin");
    gtk_widget_destroy(EspaceAdmin);

    InterEmp = lookup_widget(button, "InterEmp");
    InterEmp = create_InterEmp();
    gtk_window_set_position(GTK_WINDOW(InterEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(InterEmp);
}
void on_buttonaj_wemp_clicked(GtkButton *button,
                              gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *ajout_wemp;

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    gtk_widget_destroy(EspaceEmp);

    ajout_wemp = lookup_widget(button, "ajout_wemp");
    ajout_wemp = create_ajout_wemp();
    gtk_window_set_position(GTK_WINDOW(ajout_wemp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(ajout_wemp);
}

void on_buttonaff_wemp_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *aff_wemp;

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    gtk_widget_destroy(EspaceEmp);

    aff_wemp = lookup_widget(button, "aff_wemp");
    aff_wemp = create_aff_wemp();
    gtk_window_set_position(GTK_WINDOW(aff_wemp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(aff_wemp);
}

void on_buttonmod_wemp_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *modif_wemp;

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    gtk_widget_destroy(EspaceEmp);

    modif_wemp = lookup_widget(button, "modif_wemp");
    modif_wemp = create_modif_wemp();
    gtk_window_set_position(GTK_WINDOW(modif_wemp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(modif_wemp);
}

void on_buttonrech_wemp_clicked(GtkButton *button,
                                gpointer user_data)
{
    char fich[20], rech[20], cin[20];
    strcpy(fich, "users.txt");
    strcpy(rech, "rech.txt");
    GtkWidget *cinrech, *output, *aff_wemp, *treeview;
    UTILISATEUR u;
    FILE *f = NULL, *f1 = NULL;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    aff_wemp = lookup_widget(button, "aff_wemp");
    cinrech = lookup_widget(button, "rech_wemp");
    output = lookup_widget(button, "outputrech_wemp");

    strcpy(cin, gtk_entry_get_text(GTK_ENTRY(cinrech)));
    if (!verifCin(cin))
    {
        sprintf(msg, "Le CIN doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else if (!verifUtils(cin, fich))
    {

        sprintf(msg, "L'utilisateur n'existe pas!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        gtk_label_set_text(GTK_LABEL(output), "");
        f = fopen(fich, "r");
        f1 = fopen(rech, "w");
        if ((f != NULL) && (f1 != NULL))
        {
            while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
            {
                if ((strcmp(cin, u.log.cin) == 0) && (strcmp(u.role, "Admin") != 0))
                {
                    fprintf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
                }
            }
        }
        fclose(f1);
        fclose(f);
        gtk_window_set_position(GTK_WINDOW(aff_wemp), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(aff_wemp);
        treeview = lookup_widget(aff_wemp, "treeviewaff_wemp");
        affUtils(treeview, rech);
        remove("rech.txt");
    }
}

void on_buttonvalaj_wemp_clicked(GtkButton *button,
                                 gpointer user_data)
{
    char fich[20];
    strcpy(fich, "users.txt");
    UTILISATEUR u;
    GtkWidget *cin, *nom, *prenom, *pw, *numtel, *jour, *mois, *annee, *role;
    GtkWidget *output_ajout;
    GtkWidget *ajout_wemp, *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    output_ajout = lookup_widget(button, "outputaj_wemp");

    cin = lookup_widget(button, "cinaj_wemp");
    nom = lookup_widget(button, "nomaj_wemp");
    prenom = lookup_widget(button, "pnomaj_wemp");
    pw = lookup_widget(button, "pwaj_wemp");
    numtel = lookup_widget(button, "numtelaj_wemp");
    role = lookup_widget(button, "cbroleaj_wemp");
    jour = lookup_widget(button, "spinjaj_wemp");
    mois = lookup_widget(button, "spinmaj_wemp");
    annee = lookup_widget(button, "spinaaj_wemp");

    if (!verifCin(gtk_entry_get_text(GTK_ENTRY(cin))))
    {
        sprintf(msg, "Le CIN doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (verifUtils(gtk_entry_get_text(GTK_ENTRY(cin)), fich))
    {
        sprintf(msg, "L'utilisateur existe déjà!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (verifNum(gtk_entry_get_text(GTK_ENTRY(nom))))
    {
        sprintf(msg, "Le nom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if ((verifNum(gtk_entry_get_text(GTK_ENTRY(prenom)))))
    {
        sprintf(msg, "Le prénom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (!verifCin(gtk_entry_get_text(GTK_ENTRY(numtel))))
    {
        sprintf(msg, "Le numero telephonique doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        strcpy(u.log.cin, gtk_entry_get_text(GTK_ENTRY(cin)));
        strcpy(u.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
        strcpy(u.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
        strcpy(u.log.pw, gtk_entry_get_text(GTK_ENTRY(pw)));
        strcpy(u.numTel, gtk_entry_get_text(GTK_ENTRY(numtel)));
        strcpy(u.role, gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)));

        suppEspaces(u.nom);
        suppEspaces(u.prenom);

        u.date.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
        u.date.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
        u.date.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
        strcpy(u.sexe, "Homme");
        if (sexeaj_wemp == 1)
        {
            strcpy(u.sexe, "Homme");
        }
        else if (sexeaj_wemp == 2)
        {
            strcpy(u.sexe, "Femme");
        }
        ajoutUtils(u, fich);
        ajout_wemp = lookup_widget(button, "ajout_wemp");
        //gtk_widget_destroy(ajout_wemp);
        succ_wadm = lookup_widget(button, "succ_wadm");
        succ_wadm = create_succ_wadm();
        gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Ajout");
        gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(succ_wadm);
        msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
        sprintf(msg, "Utilisateur ajouté avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
    }
}

void on_buttonretaj_wemp_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *ajout_wemp;

    ajout_wemp = lookup_widget(button, "ajout_wemp");
    gtk_widget_destroy(ajout_wemp);

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    EspaceEmp = create_EspaceEmp();
    gtk_window_set_position(GTK_WINDOW(EspaceEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(EspaceEmp);
}

void on_fraj_wemp_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexeaj_wemp = 2;
    }
}

void on_hraj_wemp_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexeaj_wemp = 1;
    }
}

void on_lsemp_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolemod_wemp = 1;
    }
}

void on_hrmod_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexemod_wemp = 1;
    }
}

void on_frmod_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexemod_wemp = 2;
    }
}

void on_buttonvalmod_wemp_clicked(GtkButton *button,
                                  gpointer user_data)
{
    char fich[20];
    strcpy(fich, "users.txt");
    UTILISATEUR u;
    GtkWidget *cin, *nom, *prenom, *pw, *numtel, *jour, *mois, *annee, *role;
    GtkWidget *ad, *admin, *emp, *employe, *ouv, *ouvrier;
    GtkWidget *output_modif;
    GtkWidget *modif_wemp, *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    modif_wemp = lookup_widget(button, "modif_wemp");
    output_modif = lookup_widget(button, "outputmod_wemp");

    nom = lookup_widget(button, "nommod_wemp");
    prenom = lookup_widget(button, "prnommod_wemp");
    pw = lookup_widget(button, "pwmod_wemp");
    numtel = lookup_widget(button, "numtelmod_wemp");
    role = lookup_widget(button, "cbrolemod_wemp");
    jour = lookup_widget(button, "spinjmod_wemp");
    mois = lookup_widget(button, "spinmmod_wemp");
    annee = lookup_widget(button, "spinamod_wemp");

    emp = lookup_widget(button, "lsemp_wemp");
    ouv = lookup_widget(button, "lsouv_wemp");

    employe = lookup_widget(button, "cbempmodif_wemp");
    ouvrier = lookup_widget(button, "cbouvmodif_wemp");

    if (verifNum(gtk_entry_get_text(GTK_ENTRY(nom))))
    {
        sprintf(msg, "Le nom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else if ((verifNum(gtk_entry_get_text(GTK_ENTRY(prenom)))))
    {
        sprintf(msg, "Le prénom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else if (!verifCin(gtk_entry_get_text(GTK_ENTRY(numtel))))
    {
        sprintf(msg, "Le numero telephonique doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
        {
            strcpy(u.log.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
        }
        else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
        {
            strcpy(u.log.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
        }
        strcpy(u.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
        strcpy(u.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
        strcpy(u.log.pw, gtk_entry_get_text(GTK_ENTRY(pw)));
        strcpy(u.numTel, gtk_entry_get_text(GTK_ENTRY(numtel)));
        strcpy(u.role, gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)));

        suppEspaces(u.nom);
        suppEspaces(u.prenom);

        u.date.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
        u.date.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
        u.date.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
        strcpy(u.sexe, "Homme");
        if (sexemod_wemp == 1)
        {
            strcpy(u.sexe, "Homme");
        }
        else if (sexemod_wemp == 2)
        {
            strcpy(u.sexe, "Femme");
        }
        modifUtils(u, u.log.cin, fich);
        modif_wemp = lookup_widget(button, "modif_wemp");
        // gtk_widget_destroy(modif_wemp);
        succ_wadm = lookup_widget(button, "succ_wadm");
        succ_wadm = create_succ_wadm();
        gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Modification");
        gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(succ_wadm);
        msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
        sprintf(msg, "Modification effectuee avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
    }
}

void on_lsouv_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolemod_wemp = 2;
    }
}

void on_lsempsup_wemp_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolesup_wemp = 1;
    }
}

void on_lsouvsup_wemp_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolesup_wemp = 2;
    }
}

void on_buttonsuppr_wemp_clicked(GtkButton *button,
                                 gpointer user_data)
{
    char fich[20];
    strcpy(fich, "users.txt");
    char cinsup[50];
    UTILISATEUR u;
    GtkWidget *ad, *admin, *emp, *employe, *ouvrier, *ouv;
    GtkWidget *succ_wadm, *msg_succ;

    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    admin = lookup_widget(button, "cbadmmodif_wemp");
    employe = lookup_widget(button, "cbempmodif_wemp");
    ouvrier = lookup_widget(button, "cbouvmodif_wemp");
    ad = lookup_widget(button, "lsadms_wemp");
    emp = lookup_widget(button, "lsemp_wemp");
    ouv = lookup_widget(button, "lsouv_wemp");
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ad)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(admin)));
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
    }
    suppUtils(cinsup, fich);
    succ_wadm = create_succ_wadm();
    gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Suppression");
    gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(succ_wadm);
    msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
    sprintf(msg, "Utilisateur supprimé!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
}

void on_buttonokmod_wemp_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *nom, *prenom, *pw, *numtel, *role, *jour, *mois, *annee, *admin, *employe, *ouvrier, *homme, *femme;
    GtkWidget *ad, *emp, *ouv;
    GtkWidget *output_modif;
    UTILISATEUR u;
    char fich[20];
    strcpy(fich, "users.txt");

    output_modif = lookup_widget(button, "outputmod_wemp");
    gtk_label_set_text(GTK_LABEL(output_modif), "");
    nom = lookup_widget(button, "nommod_wemp");
    prenom = lookup_widget(button, "prnommod_wemp");
    pw = lookup_widget(button, "pwmod_wemp");
    numtel = lookup_widget(button, "numtelmod_wemp");
    role = lookup_widget(button, "cbrolemod_wemp");
    jour = lookup_widget(button, "spinjmod_wemp");
    mois = lookup_widget(button, "spinmmod_wemp");
    annee = lookup_widget(button, "spinamod_wemp");

    employe = lookup_widget(button, "cbempmodif_wemp");
    ouvrier = lookup_widget(button, "cbouvmodif_wemp");
    homme = lookup_widget(button, "hrmod_wemp");
    femme = lookup_widget(button, "frmod_wemp");

    emp = lookup_widget(button, "lsemp_wemp");
    ouv = lookup_widget(button, "lsouv_wemp");
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
    {
        u = rechUtils(gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)), fich);
        gtk_combo_box_set_active(GTK_COMBO_BOX(role), 0);
        gtk_entry_set_text(GTK_ENTRY(nom), u.nom);
        gtk_entry_set_text(GTK_ENTRY(prenom), u.prenom);
        gtk_entry_set_text(GTK_ENTRY(pw), u.log.pw);
        gtk_entry_set_text(GTK_ENTRY(numtel), u.numTel);
        sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour), u.date.jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois), u.date.mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee), u.date.annee);
        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 1);
        }
    }
    else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
    {
        u = rechUtils(gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)), fich);
        gtk_combo_box_set_active(GTK_COMBO_BOX(role), 1);
        gtk_entry_set_text(GTK_ENTRY(nom), u.nom);
        gtk_entry_set_text(GTK_ENTRY(prenom), u.prenom);
        gtk_entry_set_text(GTK_ENTRY(pw), u.log.pw);
        gtk_entry_set_text(GTK_ENTRY(numtel), u.numTel);
        sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour), u.date.jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois), u.date.mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee), u.date.annee);
        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 1);
        }
    }
}

void on_buttonretmod_wemp_clicked(GtkButton *button,
                                  gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *modif_wemp;

    modif_wemp = lookup_widget(button, "modif_wemp");
    gtk_widget_destroy(modif_wemp);

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    EspaceEmp = create_EspaceEmp();
    gtk_window_set_position(GTK_WINDOW(EspaceEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(EspaceEmp);
}

void on_buttonafficher_wemp_clicked(GtkButton *button,
                                    gpointer user_data)
{
    GtkWidget *treeview, *gestionUtils, *aff_wemp;
    GtkWidget *emp, *ouv, *output;
    char fich[20];
    UTILISATEUR u;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    aff_wemp = lookup_widget(button, "aff_wemp");

    emp = lookup_widget(button, "checkemp_wemp");
    ouv = lookup_widget(button, "checkouv_wemp");
    output = lookup_widget(button, "outputrech_wemp");

    FILE *f = NULL, *ft = NULL, *fe = NULL, *fo = NULL;
    FILE *vide = NULL;

    f = fopen("users.txt", "r");
    fe = fopen("employes.txt", "w");
    fo = fopen("ouvriers.txt", "w");
    ft = fopen("empouv.txt", "w");
    vide = fopen("vide.txt", "w");
    if ((f != NULL) && (ft != NULL) && (fe != NULL) && (fo != NULL))
    {
        while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            if ((strcmp(u.role, "Employe") == 0) || (strcmp(u.role, "Ouvrier") == 0))
            {
                fprintf(ft, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            if (strcmp(u.role, "Employe") == 0)
            {
                fprintf(fe, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            if (strcmp(u.role, "Ouvrier") == 0)
            {
                fprintf(fo, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            if ((strcmp(u.role, "Admin") != 0) && (strcmp(u.role, "Ouvrier") != 0) && (strcmp(u.role, "Employe") != 0))
            {
                fprintf(vide, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
        }
    }
    fclose(f);
    fclose(ft);
    fclose(fe);
    fclose(fo);
    fclose(vide);
    if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON(emp)) && gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ouv)))
    {
        strcpy(fich, "empouv.txt");
    }
    else if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON(emp)) && !gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ouv)))
    {
        strcpy(fich, "employes.txt");
    }
    else if (!gtk_toggle_button_get_active(GTK_CHECK_BUTTON(emp)) && gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ouv)))
    {
        strcpy(fich, "ouvriers.txt");
    }
    else
    {
        sprintf(msg, "<- Selectionnez\nau moins un utilisateur!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
        strcpy(fich, "vide.txt");
    }

    //gtk_widget_destroy(aff_wemp);
    //aff_wemp = create_aff_wemp();
    gtk_window_set_position(GTK_WINDOW(aff_wemp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(aff_wemp);
    treeview = lookup_widget(aff_wemp, "treeviewaff_wemp");
    affUtils(treeview, fich);
    remove("employes.txt");
    remove("ouvriers.txt");
    remove("empouv.txt");
    remove("vide.txt");
}

void on_buttonretaff_wemp_clicked(GtkButton *button,
                                  gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *aff_wemp;

    aff_wemp = lookup_widget(button, "aff_wemp");
    gtk_widget_destroy(aff_wemp);

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    EspaceEmp = create_EspaceEmp();
    gtk_window_set_position(GTK_WINDOW(EspaceEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(EspaceEmp);
}

void on_treeviewaff_wemp_row_activated(GtkTreeView *treeview,
                                       GtkTreePath *path,
                                       GtkTreeViewColumn *column,
                                       gpointer user_data)
{
    GtkTreeIter iter;
    GtkWidget *aff_wemp, *modif_wemp;
    gchar *cin, *pw, *nom, *prenom, *dateNaiss, *numtel, *sexe, *role;
    GtkWidget *CIN, *PW, *NOM, *PRENOM, *JOUR, *MOIS, *ANNEE, *NUMTEL, *HOMME, *FEMME, *ROLE, *AD, *EMP, *OUV;
    GtkWidget *CBAD, *CBEMP, *CBOUV;
    UTILISATEUR u;
    int ligne;
    char fich[50];
    FILE *f = NULL, *fe = NULL, *fo = NULL;

    f = fopen("users.txt", "r");
    fe = fopen("employes.txt", "w");
    fo = fopen("ouvriers.txt", "w");

    if ((f != NULL) && (fe != NULL) && (fo != NULL))
    {
        while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            if (strcmp(u.role, "Employe") == 0)
            {
                fprintf(fe, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            if (strcmp(u.role, "Ouvrier") == 0)
            {
                fprintf(fo, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
        }
    }
    fclose(f);
    fclose(fe);
    fclose(fo);

    aff_wemp = lookup_widget(treeview, "aff_wemp");
    GtkTreeModel *model = gtk_tree_view_get_model(treeview);
    if (gtk_tree_model_get_iter(model, &iter, path))
    {
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &cin, 1, &pw, 2, &nom, 3, &prenom, 4, &dateNaiss, 5, &numtel, 6, &sexe, 7, &role, -1);
        strcpy(u.log.cin, cin);
        strcpy(u.log.pw, pw);
        strcpy(u.nom, nom);
        strcpy(u.prenom, prenom);
        strcpy(u.dateNaiss, dateNaiss);
        strcpy(u.numTel, numtel);
        strcpy(u.sexe, sexe);
        strcpy(u.role, role);
        sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);

        modif_wemp = create_modif_wemp();
        gtk_widget_hide(aff_wemp);
        gtk_window_set_position(GTK_WINDOW(modif_wemp), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(modif_wemp);

        NOM = lookup_widget(modif_wemp, "nommod_wemp");
        PRENOM = lookup_widget(modif_wemp, "prnommod_wemp");
        ROLE = lookup_widget(modif_wemp, "cbrolemod_wemp");
        JOUR = lookup_widget(modif_wemp, "spinjmod_wemp");
        MOIS = lookup_widget(modif_wemp, "spinmmod_wemp");
        ANNEE = lookup_widget(modif_wemp, "spinamod_wemp");
        NUMTEL = lookup_widget(modif_wemp, "numtelmod_wemp");
        PW = lookup_widget(modif_wemp, "pwmod_wemp");
        HOMME = lookup_widget(modif_wemp, "hrmod_wemp");
        FEMME = lookup_widget(modif_wemp, "frmod_wemp");

        EMP = lookup_widget(modif_wemp, "lsemp_wemp");
        OUV = lookup_widget(modif_wemp, "lsouv_wemp");

        CBEMP = lookup_widget(modif_wemp, "cbempmodif_wemp");
        CBOUV = lookup_widget(modif_wemp, "cbouvmodif_wemp");

        gtk_entry_set_text(GTK_ENTRY(NOM), nom);
        gtk_entry_set_text(GTK_ENTRY(PRENOM), prenom);
        gtk_entry_set_text(GTK_ENTRY(CIN), cin);
        gtk_entry_set_text(GTK_ENTRY(PW), pw);
        gtk_entry_set_text(GTK_ENTRY(NUMTEL), numtel);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(JOUR), u.date.jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(MOIS), u.date.mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(ANNEE), u.date.annee);
        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 1);
        }
        if ((strcmp(u.role, "Employe") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(EMP), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(OUV), 0);
            gtk_combo_box_set_active(GTK_COMBO_BOX(ROLE), 0);
            ligne = rechLigne(u.log.cin, "employes.txt");
            ligne -= 1;
            gtk_combo_box_set_active(GTK_COMBO_BOX(CBEMP), ligne);
        }
        else if ((strcmp(u.role, "Ouvrier") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(EMP), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(OUV), 1);
            gtk_combo_box_set_active(GTK_COMBO_BOX(ROLE), 1);
            ligne = rechLigne(u.log.cin, "ouvriers.txt");
            ligne -= 1;
            gtk_combo_box_set_active(GTK_COMBO_BOX(CBOUV), ligne);
        }
    }
    remove("employes.txt");
    remove("ouvriers.txt");
}
void on_buttondcnx_wemp_clicked(GtkButton *button,
                                gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *Authentification;

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    gtk_widget_destroy(EspaceEmp);

    Authentification = lookup_widget(button, "Authentification");
    Authentification = create_Authentification();
    gtk_window_set_position(GTK_WINDOW(Authentification), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(Authentification);
}

void on_buttonviewaj_wadm_toggled(GtkToggleButton *togglebutton,
                                  gpointer user_data)
{
    GtkWidget *pwaj_wadm;
    pwaj_wadm = lookup_widget(GTK_WIDGET(togglebutton), "pwaj_wadm");
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
        gtk_entry_set_visibility(GTK_ENTRY(pwaj_wadm), TRUE);
    else
        gtk_entry_set_visibility(GTK_ENTRY(pwaj_wadm), FALSE);
}

void on_buttonviewmod_wadm_toggled(GtkToggleButton *togglebutton,
                                   gpointer user_data)
{
    GtkWidget *pwmod_wadm;
    pwmod_wadm = lookup_widget(GTK_WIDGET(togglebutton), "pwmod_wadm");
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
        gtk_entry_set_visibility(GTK_ENTRY(pwmod_wadm), TRUE);
    else
        gtk_entry_set_visibility(GTK_ENTRY(pwmod_wadm), FALSE);
}

void on_buttonview_auth_toggled(GtkToggleButton *togglebutton,
                                gpointer user_data)
{
    GtkWidget *entryMdp;
    entryMdp = lookup_widget(GTK_WIDGET(togglebutton), "entryMdp");
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
        gtk_entry_set_visibility(GTK_ENTRY(entryMdp), TRUE);
    else
        gtk_entry_set_visibility(GTK_ENTRY(entryMdp), FALSE);
}

void on_buttonviewaj_wemp_toggled(GtkToggleButton *togglebutton,
                                  gpointer user_data)
{
    GtkWidget *pwaj_wemp;
    pwaj_wemp = lookup_widget(GTK_WIDGET(togglebutton), "pwaj_wemp");
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
        gtk_entry_set_visibility(GTK_ENTRY(pwaj_wemp), TRUE);
    else
        gtk_entry_set_visibility(GTK_ENTRY(pwaj_wemp), FALSE);
}

void on_buttonviewmod_wemp_toggled(GtkToggleButton *togglebutton,
                                   gpointer user_data)
{
    GtkWidget *pwmod_wemp;
    pwmod_wemp = lookup_widget(GTK_WIDGET(togglebutton), "pwmod_wemp");
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
        gtk_entry_set_visibility(GTK_ENTRY(pwmod_wemp), TRUE);
    else
        gtk_entry_set_visibility(GTK_ENTRY(pwmod_wemp), FALSE);
}

/*#######################/GESTION DES ABSENCES/#######################*/
void on_buttonabs_wadm_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *gestionAbs_wadm;

    gestionUtils = lookup_widget(button, "gestionUtils");
    gtk_widget_destroy(gestionUtils);

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gestionAbs_wadm = create_gestionAbs_wadm();
    gtk_window_set_position(GTK_WINDOW(gestionAbs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionAbs_wadm);
}
void on_buttonabs_wemp_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *gestionAbs_wadm;

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    gtk_widget_destroy(EspaceEmp);

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gestionAbs_wadm = create_gestionAbs_wadm();
    gtk_window_set_position(GTK_WINDOW(gestionAbs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionAbs_wadm);
}

void on_buttonmarqabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *marqAbs_wadm;

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gtk_widget_destroy(gestionAbs_wadm);

    marqAbs_wadm = lookup_widget(button, "marqAbs_wadm");
    marqAbs_wadm = create_marqAbs_wadm();
    gtk_window_set_position(GTK_WINDOW(marqAbs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(marqAbs_wadm);
}
void on_buttonaffichabs_wadm_clicked(GtkButton *button,
                                     gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *affabs_wadm;

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gtk_widget_destroy(gestionAbs_wadm);

    affabs_wadm = lookup_widget(button, "affabs_wadm");
    affabs_wadm = create_affabs_wadm();
    gtk_window_set_position(GTK_WINDOW(affabs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(affabs_wadm);
}
void on_buttontauxabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *tauxabs_wadm;

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gtk_widget_destroy(gestionAbs_wadm);

    tauxabs_wadm = lookup_widget(button, "tauxabs_wadm");
    tauxabs_wadm = create_tauxabs_wadm();
    gtk_window_set_position(GTK_WINDOW(tauxabs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(tauxabs_wadm);
}

void on_buttondateabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data)
{
    GtkWidget *jour, *mois, *annee;
    OUVRIER o;
    jour = lookup_widget(button, "spinjabs_wadm");
    mois = lookup_widget(button, "spinmabs_wadm");
    annee = lookup_widget(button, "spinaabs_wadm");
    o = dateAuj(o);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour), o.dateAbs.jour);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois), o.dateAbs.mois);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee), o.dateAbs.annee);
}
void on_buttonvalafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data)
{
    char fich[20];
    strcpy(fich, "absences.txt");
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    OUVRIER o;
    FILE *f1;
    GtkWidget *emp, *employe, *ouv, *ouvrier, *jour, *mois, *annee, *abs, *pres, *valAbs;
    GtkWidget *output;
    int j, m, a;
    char date[100];
    int test = 0;

    output = lookup_widget(button, "outputabs_wadm");
    emp = lookup_widget(button, "lsemabs_wadm");
    ouv = lookup_widget(button, "lsouvabs_wadm");
    employe = lookup_widget(button, "cbempabs_wadm");
    ouvrier = lookup_widget(button, "cbouvabs_wadm");
    jour = lookup_widget(button, "spinjabs_wadm");
    mois = lookup_widget(button, "spinmabs_wadm");
    annee = lookup_widget(button, "spinaabs_wadm");
    abs = lookup_widget(button, "abs_wadm");
    pres = lookup_widget(button, "pres_wadm");

    j = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
    m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
    a = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
    sprintf(date, "%d/%d/%d", j, m, a);

    f1 = fopen(fich, "a+");
    if (f1 != NULL)
    {
        while (fscanf(f1, "%s %s %s %s\n", o.logAbs.cin, o.date, o.valAbs, o.roleAbs) != EOF)
        {
            if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
            {
                if ((strcmp(o.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe))) == 0) && (strcmp(o.date, date)) == 0)
                {
                    test = 1;
                }
            }
            else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
            {
                if ((strcmp(o.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier))) == 0) && (strcmp(o.date, date)) == 0)
                {
                    test = 1;
                }
            }
        }
    }
    fclose(f1);
    if (test)
    {
        sprintf(msg, "Absence déjà affectée !");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else
    {
        if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
        {
            strcpy(o.roleAbs, "Employe");
            strcpy(o.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
        }
        else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
        {
            strcpy(o.roleAbs, "Ouvrier");
            strcpy(o.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
        }
        o.dateAbs.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
        o.dateAbs.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
        o.dateAbs.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
        sprintf(o.date, "%d/%d/%d", o.dateAbs.jour, o.dateAbs.mois, o.dateAbs.annee);
        if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(abs)))
        {
            strcpy(o.valAbs, "Absent");
        }
        else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(pres)))
        {
            strcpy(o.valAbs, "Present");
        }
        marquerAbs(o, fich);
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        sprintf(msg, "Absence affectee avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
}

void on_buttonretafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *marqAbs_wadm;
    marqAbs_wadm = lookup_widget(button, "marqAbs_wadm");
    gtk_widget_destroy(marqAbs_wadm);

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gestionAbs_wadm = create_gestionAbs_wadm();
    gtk_window_set_position(GTK_WINDOW(gestionAbs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionAbs_wadm);
}

void on_buttondcnxabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *Authentification;

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gtk_widget_destroy(gestionAbs_wadm);

    Authentification = lookup_widget(button, "Authentification");
    Authentification = create_Authentification();
    gtk_window_set_position(GTK_WINDOW(Authentification), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(Authentification);
}

void on_buttonretabs_wadm_clicked(GtkButton *button,
                                  gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *EspaceEmp;

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gtk_widget_destroy(gestionAbs_wadm);

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    EspaceEmp = create_EspaceEmp();
    gtk_window_set_position(GTK_WINDOW(EspaceEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(EspaceEmp);
}

void on_lsemabs_wadm_toggled(GtkToggleButton *togglebutton,
                             gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        roleabs_wadm = 1;
    }
}

void on_lsouvabs_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        roleabs_wadm = 2;
    }
}

void on_abs_wadm_toggled(GtkToggleButton *togglebutton,
                         gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        presabs_wadm = 0;
    }
}

void on_pres_wadm_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        presabs_wadm = 1;
    }
}

void on_treeviewaffabs_wadm_row_activated(GtkTreeView *treeviewaffabs,
                                          GtkTreePath *path,
                                          GtkTreeViewColumn *column,
                                          gpointer user_data)
{
    GtkTreeIter iter;
    gchar *cin, *nom, *prenom, *jtrav, *jabs, *taux;
    GtkWidget *affabs_wadm, *tauxabs_wadm;
    GtkWidget *emp, *employe, *ouv, *ouvrier;
    OUVRIER o;
    UTILISATEUR u;
    int ligne;
    char fich[50];
    FILE *f = NULL, *fe = NULL, *fo = NULL;

    f = fopen("users.txt", "r");
    fe = fopen("employes.txt", "w");
    fo = fopen("ouvriers.txt", "w");

    if ((f != NULL) && (fe != NULL) && (fo != NULL))
    {
        while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            if (strcmp(u.role, "Employe") == 0)
            {
                fprintf(fe, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            if (strcmp(u.role, "Ouvrier") == 0)
            {
                fprintf(fo, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
        }
    }
    fclose(f);
    fclose(fe);
    fclose(fo);
    affabs_wadm = lookup_widget(treeviewaffabs, "affabs_wadm");
    GtkTreeModel *model = gtk_tree_view_get_model(treeviewaffabs);
    if (gtk_tree_model_get_iter(model, &iter, path))
    {
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &cin, 1, &nom, 2, &prenom, 3, &jtrav, 4, &jabs, 5, &taux, -1);
        strcpy(o.logAbs.cin, cin);
        strcpy(u.nom, nom);
        strcpy(u.prenom, prenom);
        strcpy(o.jtrav, jtrav);
        strcpy(o.jabs, jabs);
        strcpy(o.taux, taux);
        tauxabs_wadm = create_tauxabs_wadm();
        gtk_widget_hide(affabs_wadm);
        gtk_window_set_position(GTK_WINDOW(tauxabs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(tauxabs_wadm);

        emp = lookup_widget(tauxabs_wadm, "lsemptabs_wadm");
        ouv = lookup_widget(tauxabs_wadm, "lsouvtabs_wadm");

        employe = lookup_widget(tauxabs_wadm, "cbemptaux_wadm");
        ouvrier = lookup_widget(tauxabs_wadm, "cbouvtaux_wadm");

        f = fopen("users.txt", "r");
        if ((f != NULL))
        {
            while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
            {
                if (strcmp(o.logAbs.cin, u.log.cin) == 0)
                {
                    if (strcmp(u.role, "Employe") == 0)
                    {
                        gtk_toggle_button_set_active(GTK_RADIO_BUTTON(emp), 1);
                        gtk_toggle_button_set_active(GTK_RADIO_BUTTON(ouv), 0);
                        ligne = rechLigne(o.logAbs.cin, "employes.txt");
                        ligne -= 1;
                        gtk_combo_box_set_active(GTK_COMBO_BOX(employe), ligne);
                    }
                    if (strcmp(u.role, "Ouvrier") == 0)
                    {
                        gtk_toggle_button_set_active(GTK_RADIO_BUTTON(emp), 0);
                        gtk_toggle_button_set_active(GTK_RADIO_BUTTON(ouv), 1);
                        ligne = rechLigne(o.logAbs.cin, "ouvriers.txt");
                        ligne -= 1;
                        gtk_combo_box_set_active(GTK_COMBO_BOX(ouvrier), ligne);
                    }
                }
            }
        }
        fclose(f);
    }
    remove("employes.txt");
    remove("ouvriers.txt");
}
void on_buttonafficherabs_wadm_clicked(GtkButton *button,
                                       gpointer user_data)
{
    GtkWidget *treeviewaffabs, *affabs_wadm;
    GtkWidget *emp, *ouv, *output;
    char fich1[20], fich2[20], fich3[20];
    OUVRIER o;
    UTILISATEUR u;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    affabs_wadm = lookup_widget(button, "affabs_wadm");
    emp = lookup_widget(button, "checkempabs_wadm");
    ouv = lookup_widget(button, "checkouvabs_wadm");
    output = lookup_widget(button, "outputrechabs_wadm");

    FILE *f = NULL, *ft = NULL, *fe = NULL, *fo = NULL;
    FILE *vide = NULL;
    f = fopen("users.txt", "r");
    fe = fopen("employes.txt", "w");
    fo = fopen("ouvriers.txt", "w");
    ft = fopen("empouv.txt", "w");
    vide = fopen("vide.txt", "w");
    if ((f != NULL) && (ft != NULL) && (fe != NULL) && (fo != NULL))
    {
        while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            if ((strcmp(u.role, "Employe") == 0) || (strcmp(u.role, "Ouvrier") == 0))
            {
                fprintf(ft, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);

                if (strcmp(u.role, "Employe") == 0)
                {
                    fprintf(fe, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
                }
                else if (strcmp(u.role, "Ouvrier") == 0)
                {
                    fprintf(fo, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
                }
            }
            if ((strcmp(u.role, "Admin") != 0) && (strcmp(u.role, "Ouvrier") != 0) && (strcmp(u.role, "Employe") != 0))
            {
                fprintf(vide, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
        }
    }
    fclose(f);
    fclose(ft);
    fclose(fe);
    fclose(fo);
    fclose(vide);
    strcpy(fich2, "absences.txt");
    strcpy(fich3, "taux.txt");
    if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON(emp)) && gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ouv)))
    {
        tauxAbs("empouv.txt", fich2);
        gtk_window_set_position(GTK_WINDOW(affabs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(affabs_wadm);
        treeviewaffabs = lookup_widget(affabs_wadm, "treeviewaffabs_wadm");
        affAbs(treeviewaffabs, fich3);
    }
    else if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON(emp)) && !gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ouv)))
    {
        tauxAbs("employes.txt", fich2);
        gtk_window_set_position(GTK_WINDOW(affabs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(affabs_wadm);
        treeviewaffabs = lookup_widget(affabs_wadm, "treeviewaffabs_wadm");
        affAbs(treeviewaffabs, fich3);
    }
    else if (!gtk_toggle_button_get_active(GTK_CHECK_BUTTON(emp)) && gtk_toggle_button_get_active(GTK_CHECK_BUTTON(ouv)))
    {
        tauxAbs("ouvriers.txt", fich2);
        gtk_window_set_position(GTK_WINDOW(affabs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(affabs_wadm);
        treeviewaffabs = lookup_widget(affabs_wadm, "treeviewaffabs_wadm");
        affAbs(treeviewaffabs, fich3);
    }
    else
    {
        sprintf(msg, "<- Selectionnez\nau moins un utilisateur!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
        gtk_window_set_position(GTK_WINDOW(affabs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(affabs_wadm);
        treeviewaffabs = lookup_widget(affabs_wadm, "treeviewaffabs_wadm");
        affAbs(treeviewaffabs, "vide.txt");
    }
    remove("empouv.txt");
    remove("employes.txt");
    remove("ouvriers.txt");
    remove("taux.txt");
    remove("vide.txt");
}

void on_buttonrechabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data)
{
    char fich[20], rech[20], tx[20], absc[20], cin[20];
    char fich1[20], fich2[20], fich3[20];
    strcpy(fich, "users.txt");
    strcpy(absc, "absences.txt");
    strcpy(tx, "taux.txt");
    strcpy(rech, "rech.txt");
    GtkWidget *cinrech, *output, *affabs_wadm, *treeviewaffabs;
    UTILISATEUR u;
    OUVRIER o;
    FILE *f = NULL, *f1 = NULL;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    affabs_wadm = lookup_widget(button, "affabs_wadm");
    cinrech = lookup_widget(button, "rechabs_wadm");
    output = lookup_widget(button, "outputrechabs_wadm");
    FILE *fu = NULL, *ft = NULL;
    strcpy(cin, gtk_entry_get_text(GTK_ENTRY(cinrech)));
    if (!verifCin(cin))
    {
        sprintf(msg, "Le CIN doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else if (!verifUtils(cin, fich))
    {

        sprintf(msg, "L'utilisateur n'existe pas!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else
    {
        gtk_label_set_text(GTK_LABEL(output), "");
        fu = fopen("users.txt", "r");
        ft = fopen("empouv.txt", "w");
        if ((fu != NULL) && (ft != NULL))
        {
            while (fscanf(fu, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
            {
                if ((strcmp(u.role, "Employe") == 0) || (strcmp(u.role, "Ouvrier") == 0))
                {
                    fprintf(ft, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
                }
            }
        }
        fclose(fu);
        fclose(ft);
        tauxAbs("empouv.txt", absc);
        f = fopen(tx, "r");
        f1 = fopen(rech, "w");
        if ((f != NULL) && (f1 != NULL))
        {
            while (fscanf(f, "%s %s %s %s %s %s\n", u.log.cin, u.nom, u.prenom, o.jtrav, o.jabs, o.taux) != EOF)
            {
                if (strcmp(cin, u.log.cin) == 0)
                {
                    fprintf(f1, "%s %s %s %s %s %s\n", u.log.cin, u.nom, u.prenom, o.jtrav, o.jabs, o.taux);
                }
            }
        }
        fclose(f1);
        fclose(f);
        gtk_window_set_position(GTK_WINDOW(affabs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(affabs_wadm);
        treeviewaffabs = lookup_widget(affabs_wadm, "treeviewaffabs_wadm");
        affAbs(treeviewaffabs, rech);
        remove("empouv.txt");
        remove("rech.txt");
        remove("taux.txt");
    }
}
void on_buttonretaffabs_wadm_clicked(GtkButton *button,
                                     gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *affabs_wadm;

    affabs_wadm = lookup_widget(button, "affabs_wadm");
    gtk_widget_destroy(affabs_wadm);

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gestionAbs_wadm = create_gestionAbs_wadm();
    gtk_window_set_position(GTK_WINDOW(gestionAbs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionAbs_wadm);
}

void on_lsemptabs_wadm_toggled(GtkToggleButton *togglebutton,
                               gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        roletabs_wadm = 1;
    }
}

void on_lsouvtabs_wadm_toggled(GtkToggleButton *togglebutton,
                               gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        roletabs_wadm = 2;
    }
}

void on_buttonafftabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data)
{
    char fich[20];
    strcpy(fich, "absences.txt");
    char cinmod[50], dtdeb[50], dtfin[50];
    char nom[50], pnom[50];
    char msg[50], duree[50], NP[50], *markup, *markupx, *markupnm;
    const char *format = "<span foreground=\"#8000FF\"><i><b>\%s</b></i></span>";
    const char *formatx = "<span foreground=\"#FF007B\"><u><b>\%s</b></u></span>";
    const char *formatnm = "<span foreground=\"#0082FF\"><i><b>\%s</b></i></span>";
    int jdeb, mdeb, adeb;
    int jfin, mfin, afin;
    OUVRIER m;
    UTILISATEUR u;
    FILE *f = NULL;
    GtkWidget *emp, *employe, *ouvrier, *ouv, *caldeb, *calfin, *output, *tx, *nmpm;
    employe = lookup_widget(button, "cbemptaux_wadm");
    ouvrier = lookup_widget(button, "cbouvtaux_wadm");
    emp = lookup_widget(button, "lsemptabs_wadm");
    ouv = lookup_widget(button, "lsouvtabs_wadm");
    caldeb = lookup_widget(button, "calabsd_wadm");
    calfin = lookup_widget(button, "calabsa_wadm");
    output = lookup_widget(button, "output_afftabs_wadm");
    tx = lookup_widget(button, "tx_wadm");
    nmpm = lookup_widget(button, "outputtaux_wadm");
    gtk_label_set_text(GTK_LABEL(output), "");
    gtk_label_set_text(GTK_LABEL(tx), "");
    gtk_label_set_text(GTK_LABEL(nmpm), "");

    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
    {
        strcpy(m.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
    {
        strcpy(m.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
    }
    f = fopen("users.txt", "r");
    if ((f != NULL))
    {
        while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            if (strcmp(m.logAbs.cin, u.log.cin) == 0)
            {
                strcpy(nom, u.nom);
                strcpy(pnom, u.prenom);
            }
        }
    }
    fclose(f);
    gtk_calendar_get_date(GTK_CALENDAR(caldeb), &adeb, &mdeb, &jdeb);
    gtk_calendar_get_date(GTK_CALENDAR(calfin), &afin, &mfin, &jfin);
    sprintf(dtdeb, "%d/%d/%d", jdeb, mdeb + 1, adeb);
    sprintf(dtfin, "%d/%d/%d", jfin, mfin + 1, afin);
    m = calcAbs(m.logAbs.cin, dtdeb, dtfin, fich);
    if (m.ctot == 0)
    {
        format = "<span foreground=\"red\"><u><b>\%s</b></u></span>";
        sprintf(msg, "Aucune information trouvée !");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else
    {
        sprintf(NP, "%s %s", pnom, nom);
        markupnm = g_markup_printf_escaped(formatnm, NP);
        gtk_label_set_markup(GTK_LABEL(nmpm), markupnm);

        sprintf(duree, "Durée : du %s au %s", dtdeb, dtfin);
        markup = g_markup_printf_escaped(format, duree);
        gtk_label_set_markup(GTK_LABEL(output), markup);

        sprintf(msg, "Taux d'absenteisme = %s", m.taux);
        markupx = g_markup_printf_escaped(formatx, msg);
        gtk_label_set_markup(GTK_LABEL(tx), markupx);
    }
}

void on_buttonretafftabs_wadm_clicked(GtkButton *button,
                                      gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *tauxabs_wadm;

    tauxabs_wadm = lookup_widget(button, "tauxabs_wadm");
    gtk_widget_destroy(tauxabs_wadm);

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gestionAbs_wadm = create_gestionAbs_wadm();
    gtk_window_set_position(GTK_WINDOW(gestionAbs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionAbs_wadm);
}

void on_buttonmodafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data)
{
    char fich[20];
    strcpy(fich, "absences.txt");
    char cinmod[50];
    OUVRIER m;
    GtkWidget *emp, *employe, *ouvrier, *ouv, *jour, *mois, *annee, *abs, *pres;
    GtkWidget *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"purple\"><b>\%s</b></span>";
    jour = lookup_widget(button, "spinjabs_wadm");
    mois = lookup_widget(button, "spinmabs_wadm");
    annee = lookup_widget(button, "spinaabs_wadm");
    employe = lookup_widget(button, "cbempabs_wadm");
    ouvrier = lookup_widget(button, "cbouvabs_wadm");
    emp = lookup_widget(button, "lsemabs_wadm");
    ouv = lookup_widget(button, "lsouvabs_wadm");
    abs = lookup_widget(button, "abs_wadm");
    pres = lookup_widget(button, "pres_wadm");

    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
    {
        strcpy(m.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
        strcpy(m.roleAbs, "Employe");
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
    {
        strcpy(m.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
        strcpy(m.roleAbs, "Ouvrier");
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(abs)))
    {
        strcpy(m.valAbs, "Absent");
    }
    else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(pres)))
    {
        strcpy(m.valAbs, "Present");
    }
    m.dateAbs.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
    m.dateAbs.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
    m.dateAbs.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
    //sprintf(m.date, "%d/%d/%d", m.dateAbs.jour, m.dateAbs.mois, m.dateAbs.annee);

    modifAbs(m, m.logAbs.cin, fich);
    succ_wadm = create_succ_wadm();
    gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Modification");
    gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(succ_wadm);
    msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
    sprintf(msg, "Absence modifiée!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
}

void on_buttonsupafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data)
{
    char fich[20];
    strcpy(fich, "absences.txt");
    char cinsup[50];
    OUVRIER o;
    GtkWidget *emp, *employe, *ouvrier, *ouv, *jour, *mois, *annee;
    GtkWidget *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    int j, m, a;
    char date[100];
    jour = lookup_widget(button, "spinjabs_wadm");
    mois = lookup_widget(button, "spinmabs_wadm");
    annee = lookup_widget(button, "spinaabs_wadm");
    employe = lookup_widget(button, "cbempabs_wadm");
    ouvrier = lookup_widget(button, "cbouvabs_wadm");
    emp = lookup_widget(button, "lsempabs_wadm");
    ouv = lookup_widget(button, "lsouvabs_wadm");

    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
    }

    j = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
    m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
    a = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
    sprintf(date, "%d/%d/%d", j, m, a);

    suppAbs(cinsup, date, fich);
    succ_wadm = create_succ_wadm();
    gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Suppression");
    gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(succ_wadm);
    msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
    sprintf(msg, "Absence supprimée!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
}

void on_buttonret_wemp_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *InterEmp;

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    gtk_widget_destroy(EspaceEmp);

    InterEmp = lookup_widget(button, "InterEmp");
    InterEmp = create_InterEmp();
    gtk_window_set_position(GTK_WINDOW(InterEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(InterEmp);
}
void on_buttongutils_ee_clicked(GtkButton *button,
                                gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *InterEmp;

    InterEmp = lookup_widget(button, "InterEmp");
    gtk_widget_destroy(InterEmp);

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    EspaceEmp = create_EspaceEmp();
    gtk_window_set_position(GTK_WINDOW(EspaceEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(EspaceEmp);
}
void on_buttondcnx_ee_clicked(GtkButton *button,
                              gpointer user_data)
{
    GtkWidget *InterEmp;
    GtkWidget *Authentification;

    InterEmp = lookup_widget(button, "InterEmp");
    gtk_widget_destroy(InterEmp);

    Authentification = lookup_widget(button, "Authentification");
    Authentification = create_Authentification();
    gtk_window_set_position(GTK_WINDOW(Authentification), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(Authentification);
}
void on_buttongcal_ee_clicked(GtkButton *button,
                              gpointer user_data)
{
    GtkWidget *InterEmp;
    GtkWidget *gestionPlantation;

    InterEmp = lookup_widget(button, "InterEmp");
    gtk_widget_destroy(InterEmp);

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gestionPlantation = create_gestionPlantation();
    gtk_window_set_position(GTK_WINDOW(gestionPlantation), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionPlantation);
}

void on_buttonret_gpl_clicked(GtkButton *button,
                              gpointer user_data)
{
    GtkWidget *InterEmp;
    GtkWidget *gestionPlantation;

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gtk_widget_destroy(gestionPlantation);

    InterEmp = lookup_widget(button, "InterEmp");
    InterEmp = create_InterEmp();
    gtk_window_set_position(GTK_WINDOW(InterEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(InterEmp);
}

void on_buttondcnx_gpl_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *gestionPlantation;
    GtkWidget *Authentification;

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gtk_widget_destroy(gestionPlantation);

    Authentification = lookup_widget(button, "Authentification");
    Authentification = create_Authentification();
    gtk_window_set_position(GTK_WINDOW(Authentification), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(Authentification);
}

void on_buttonactu_gpl_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *treeviewpl, *aff_gpl;
    GtkWidget *affrole;
    char fich[20];
    PLANTE u;
    aff_gpl = lookup_widget(button, "aff_gpl");
    affrole = lookup_widget(button, "cbtypeaff_gpl");

    FILE *f = NULL, *ff = NULL, *fl = NULL, *ft = NULL;
    f = fopen("plantes.txt", "r");
    ff = fopen("fruits.txt", "w");
    fl = fopen("legumes.txt", "w");
    if ((f != NULL) && (ff != NULL) && (fl != NULL))
    {
        while (fscanf(f, "%s %s %s %s %s %s %s \n", u.id, u.cat, u.type, u.recolte, u.stock, u.dtpl, u.dtrec) != EOF)
        {
            if (strcmp(u.cat, "Fruits") == 0)
            {
                fprintf(ff, "%s %s %s %s %s %s %s \n", u.id, u.cat, u.type, u.recolte, u.stock, u.dtpl, u.dtrec);
            }
            else if (strcmp(u.cat, "Legumes") == 0)
            {
                fprintf(fl, "%s %s %s %s %s %s %s \n", u.id, u.cat, u.type, u.recolte, u.stock, u.dtpl, u.dtrec);
            }
        }
    }
    fclose(f);
    fclose(ff);
    fclose(fl);
    if (strcmp("Tous", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        strcpy(fich, "plantes.txt");
    }
    else if (strcmp("Fruits", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        strcpy(fich, "fruits.txt");
    }
    else if (strcmp("Legumes", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        strcpy(fich, "legumes.txt");
    }
    gtk_window_set_position(GTK_WINDOW(aff_gpl), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(aff_gpl);
    treeviewpl = lookup_widget(aff_gpl, "treeviewpl_gpl");
    affPl(treeviewpl, fich);
    remove("frleg.txt");
    remove("fruits.txt");
    remove("legumes.txt");
}
void on_buttonrech_gpl_clicked(GtkButton *button,
                               gpointer user_data)
{
    char fich[20], rech[20], ID[20];
    strcpy(fich, "plantes.txt");
    strcpy(rech, "rech.txt");
    GtkWidget *idrech, *output, *aff_gpl, *treeviewgpl;
    PLANTE u;
    FILE *f = NULL, *f1 = NULL;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    aff_gpl = lookup_widget(button, "aff_gpl");
    idrech = lookup_widget(button, "rech_gpl");
    output = lookup_widget(button, "outputrech_gpl");

    strcpy(ID, gtk_entry_get_text(GTK_ENTRY(idrech)));
    suppEspaces(ID);
    if (!verifPl(ID, fich))
    {

        sprintf(msg, "La plante n'existe pas!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else
    {
        gtk_label_set_text(GTK_LABEL(output), "");
        f = fopen(fich, "r");
        f1 = fopen(rech, "w");
        if ((f != NULL) && (f1 != NULL))
        {
            while (fscanf(f, "%s %s %s %s %s %s %s \n", u.id, u.cat, u.type, u.recolte, u.stock, u.dtpl, u.dtrec) != EOF)
            {
                if (strcmp(ID, u.id) == 0)
                {
                    fprintf(f1, "%s %s %s %s %s %s %s \n", u.id, u.cat, u.type, u.recolte, u.stock, u.dtpl, u.dtrec);
                }
            }
        }
        fclose(f1);
        fclose(f);
        gtk_window_set_position(GTK_WINDOW(aff_gpl), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(aff_gpl);
        treeviewgpl = lookup_widget(aff_gpl, "treeviewpl_gpl");
        affPl(treeviewgpl, rech);
        remove("rech.txt");
    }
}
void on_buttonretaff_gpl_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *gestionPlantation;
    GtkWidget *aff_gpl;

    aff_gpl = lookup_widget(button, "aff_gpl");
    gtk_widget_destroy(aff_gpl);

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gestionPlantation = create_gestionPlantation();
    gtk_window_set_position(GTK_WINDOW(gestionPlantation), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionPlantation);
}
void on_treeviewpl_gpl_row_activated(GtkTreeView *treeviewpl,
                                     GtkTreePath *path,
                                     GtkTreeViewColumn *column,
                                     gpointer user_data)
{
    GtkTreeIter iter;
    gchar *id, *var, *type, *recolte, *dtpl, *dtrec, *stock;
    GtkWidget *aff_gpl, *modifsup_gpl;
    GtkWidget *ID;
    PLANTE p;
    PLANTE u;
    int vari;
    FILE *f1;
    char fich[20];
    aff_gpl = lookup_widget(treeviewpl, "aff_gpl");
    GtkTreeModel *model = gtk_tree_view_get_model(treeviewpl);
    if (gtk_tree_model_get_iter(model, &iter, path))
    {
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &id, 1, &var, 2, &type, 3, &recolte, 4, &stock, 5, &dtpl, 6, &dtrec, -1);
        strcpy(p.id, id);
        strcpy(p.cat, var);
        strcpy(p.type, type);
        strcpy(p.recolte, recolte);
        strcpy(p.dtpl, dtpl);
        strcpy(p.dtrec, dtrec);
        f1 = fopen("plantes.txt", "r");
        if (f1 != NULL)
        {
            while (fscanf(f1, "%s %s %s %s %s %s %s \n", u.id, u.cat, u.type, u.recolte, u.stock, u.dtpl, u.dtrec) != EOF)
            {
                if (strcmp(u.id, p.id) == 0)
                {
                    if ((strcmp(u.cat, "Fruits")) == 0)
                    {
                        vari = 1;
                    }
                    else if ((strcmp(u.cat, "Legumes")) == 0)
                    {
                        vari = 2;
                    }
                }
            }
        }
        fclose(f1);
        modifsup_gpl = create_modifsup_gpl();
        gtk_widget_hide(aff_gpl);
        gtk_window_set_position(GTK_WINDOW(modifsup_gpl), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(modifsup_gpl);

        ID = lookup_widget(modifsup_gpl, "cbidmod_gpl");
        gtk_combo_box_insert_text(GTK_COMBO_BOX(ID), 0, p.id);
        gtk_combo_box_set_active(GTK_COMBO_BOX(ID), 0);
    }
}

void on_lraj_gpl_toggled(GtkToggleButton *togglebutton,
                         gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        varaj = 2;
    }
}

void on_fraj_gpl_toggled(GtkToggleButton *togglebutton,
                         gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        varaj = 1;
    }
}

void on_buttonrejat_gpl_clicked(GtkButton *button,
                                gpointer user_data)
{
    GtkWidget *gestionPlantation;
    GtkWidget *ajout_gpl;

    ajout_gpl = lookup_widget(button, "ajout_gpl");
    gtk_widget_destroy(ajout_gpl);

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gestionPlantation = create_gestionPlantation();
    gtk_window_set_position(GTK_WINDOW(gestionPlantation), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionPlantation);
}

void on_buttonvalaj_gpl_clicked(GtkButton *button,
                                gpointer user_data)
{
    char fich[20];
    strcpy(fich, "plantes.txt");
    PLANTE p;
    GtkWidget *id, *fruits, *legumes, *typefr, *typeleg, *recolte, *qstock, *jpl, *mpl, *apl, *jrec, *mrec, *arec;
    GtkWidget *output_ajout;
    GtkWidget *ajout_gpl, *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    output_ajout = lookup_widget(button, "outputaj_gpl");
    gtk_label_set_text(GTK_LABEL(output_ajout), "");
    id = lookup_widget(button, "idaj_gpl");
    fruits = lookup_widget(button, "fraj_gpl");
    legumes = lookup_widget(button, "lraj_gpl");
    typefr = lookup_widget(button, "cbtypefaj_gpl");
    typeleg = lookup_widget(button, "cbtypelraj_gpl");
    recolte = lookup_widget(button, "recaj_gpl");
    qstock = lookup_widget(button, "stockaj_gpl");

    jpl = lookup_widget(button, "spinjplaj_gpl");
    mpl = lookup_widget(button, "spinmplaj_gpl");
    apl = lookup_widget(button, "spinaplaj_gpl");

    jrec = lookup_widget(button, "spinjraj_gpl");
    mrec = lookup_widget(button, "spinmraj_gpl");
    arec = lookup_widget(button, "spinaraj_gpl");

    if (verifPl(gtk_entry_get_text(GTK_ENTRY(id)), fich))
    {
        sprintf(msg, "La plante existe déjà!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (!verifNumPl(gtk_entry_get_text(GTK_ENTRY(recolte))))
    {
        sprintf(msg, "La recolte doit avoir que des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (!verifNumPl(gtk_entry_get_text(GTK_ENTRY(qstock))))
    {
        sprintf(msg, "La qualtite en stock doit avoir que des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        strcpy(p.id, gtk_entry_get_text(GTK_ENTRY(id)));
        strcpy(p.recolte, gtk_entry_get_text(GTK_ENTRY(recolte)));
        strcpy(p.stock, gtk_entry_get_text(GTK_ENTRY(qstock)));
        suppEspaces(p.id);
        suppEspaces(p.recolte);
        suppEspaces(p.stock);
        p.datePl.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jpl));
        p.datePl.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mpl));
        p.datePl.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(apl));

        p.dateRec.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jrec));
        p.dateRec.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mrec));
        p.dateRec.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(arec));

        //strcpy(p.cat, "Fruits");
        if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(fruits)))
        {
            strcpy(p.cat, "Fruits");
            strcpy(p.type, gtk_combo_box_get_active_text(GTK_COMBO_BOX(typefr)));
        }
        else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(legumes)))
        {
            strcpy(p.cat, "Legumes");
            strcpy(p.type, gtk_combo_box_get_active_text(GTK_COMBO_BOX(typeleg)));
        }
        ajoutPl(p, fich);
        succ_wadm = create_succ_wadm();
        gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Ajout");
        gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(succ_wadm);
        msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
        sprintf(msg, "Plante ajoutée avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
    }
}

void on_frmod_gpl_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        varmod = 1;
    }
}

void on_lrmod_gpl_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        varmod = 1;
    }
}

void on_buttonokmod_gpl_clicked(GtkButton *button,
                                gpointer user_data)
{
    GtkWidget *id, *fruits, *legumes, *typefr, *typeleg, *recolte, *qstock, *jpl, *mpl, *apl, *jrec, *mrec, *arec;
    GtkWidget *output_modif;
    PLANTE m;
    char fich[20];
    strcpy(fich, "plantes.txt");

    output_modif = lookup_widget(button, "outputmod_gpl");
    gtk_label_set_text(GTK_LABEL(output_modif), "");
    id = lookup_widget(button, "cbidmod_gpl");
    fruits = lookup_widget(button, "frmod_gpl");
    legumes = lookup_widget(button, "lrmod_gpl");
    typefr = lookup_widget(button, "cbtypefmod_gpl");
    typeleg = lookup_widget(button, "cbtypelmod_gpl");
    recolte = lookup_widget(button, "recmod_gpl");
    qstock = lookup_widget(button, "stockmod_gpl");

    jpl = lookup_widget(button, "spinjplmod_gpl");
    mpl = lookup_widget(button, "spinmplmod_gpl");
    apl = lookup_widget(button, "spinaplmod_gpl");

    jrec = lookup_widget(button, "spinjrmod_gpl");
    mrec = lookup_widget(button, "spinmrmod_gpl");
    arec = lookup_widget(button, "spinarmod_gpl");
    m = rechPl(gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)), fich);
    if ((strcmp(m.cat, "Fruits") == 0))
    {
        gtk_toggle_button_set_active(GTK_RADIO_BUTTON(fruits), 1);
        gtk_toggle_button_set_active(GTK_RADIO_BUTTON(legumes), 0);
        if (strcmp(m.type, "Clementines") == 0)
        {
            gtk_combo_box_set_active(GTK_COMBO_BOX(typefr), 0);
        }
        else if (strcmp(m.type, "Grenades") == 0)
        {
            gtk_combo_box_set_active(GTK_COMBO_BOX(typefr), 1);
        }
        else if (strcmp(m.type, "Poires") == 0)
        {
            gtk_combo_box_set_active(GTK_COMBO_BOX(typefr), 2);
        }
    }
    else if ((strcmp(m.cat, "Legumes") == 0))
    {
        gtk_toggle_button_set_active(GTK_RADIO_BUTTON(fruits), 0);
        gtk_toggle_button_set_active(GTK_RADIO_BUTTON(legumes), 1);
        if (strcmp(m.type, "Carottes") == 0)
        {
            gtk_combo_box_set_active(GTK_COMBO_BOX(typeleg), 0);
        }
        else if (strcmp(m.type, "Fenouils") == 0)
        {
            gtk_combo_box_set_active(GTK_COMBO_BOX(typeleg), 1);
        }
        else if (strcmp(m.type, "Betteraves") == 0)
        {
            gtk_combo_box_set_active(GTK_COMBO_BOX(typeleg), 2);
        }
    }
    gtk_entry_set_text(GTK_ENTRY(recolte), m.recolte);
    gtk_entry_set_text(GTK_ENTRY(qstock), m.stock);
    sscanf(m.dtpl, "%d/%d/%d", &m.datePl.jour, &m.datePl.mois, &m.datePl.annee);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(jpl), m.datePl.jour);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(mpl), m.datePl.mois);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(apl), m.datePl.annee);
    sscanf(m.dtrec, "%d/%d/%d", &m.dateRec.jour, &m.dateRec.mois, &m.dateRec.annee);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(jrec), m.dateRec.jour);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(mrec), m.dateRec.mois);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(arec), m.dateRec.annee);
}

void on_buttonvalmod_gpl_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *id, *fruits, *legumes, *typefr, *typeleg, *recolte, *qstock, *jpl, *mpl, *apl, *jrec, *mrec, *arec;
    GtkWidget *output_modif;
    GtkWidget *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    PLANTE m;
    char fich[20];
    strcpy(fich, "plantes.txt");
    PLANTE p;

    output_modif = lookup_widget(button, "outputmod_gpl");
    gtk_label_set_text(GTK_LABEL(output_modif), "");
    id = lookup_widget(button, "cbidmod_gpl");
    fruits = lookup_widget(button, "frmod_gpl");
    legumes = lookup_widget(button, "lrmod_gpl");
    typefr = lookup_widget(button, "cbtypefmod_gpl");
    typeleg = lookup_widget(button, "cbtypelmod_gpl");
    recolte = lookup_widget(button, "recmod_gpl");
    qstock = lookup_widget(button, "stockmod_gpl");

    jpl = lookup_widget(button, "spinjplmod_gpl");
    mpl = lookup_widget(button, "spinmplmod_gpl");
    apl = lookup_widget(button, "spinaplmod_gpl");

    jrec = lookup_widget(button, "spinjrmod_gpl");
    mrec = lookup_widget(button, "spinmrmod_gpl");
    arec = lookup_widget(button, "spinarmod_gpl");
    if (!verifNumPl(gtk_entry_get_text(GTK_ENTRY(recolte))))
    {
        sprintf(msg, "La recolte doit avoir que des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else if (!verifNumPl(gtk_entry_get_text(GTK_ENTRY(qstock))))
    {
        sprintf(msg, "La qualtite en stock doit avoir que des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        strcpy(p.id, gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
        strcpy(p.recolte, gtk_entry_get_text(GTK_ENTRY(recolte)));
        strcpy(p.stock, gtk_entry_get_text(GTK_ENTRY(qstock)));
        suppEspaces(p.recolte);
        suppEspaces(p.stock);

        p.datePl.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jpl));
        p.datePl.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mpl));
        p.datePl.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(apl));

        p.dateRec.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jrec));
        p.dateRec.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mrec));
        p.dateRec.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(arec));
        strcpy(p.cat, "Fruits");
        if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(fruits)))
        {
            strcpy(p.type, gtk_combo_box_get_active_text(GTK_COMBO_BOX(typefr)));
            strcpy(p.cat, "Fruits");
        }
        else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(legumes)))
        {
            strcpy(p.type, gtk_combo_box_get_active_text(GTK_COMBO_BOX(typeleg)));
            strcpy(p.cat, "Legumes");
        }
        modifPl(p, p.id, fich);
        succ_wadm = create_succ_wadm();
        gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Modification");
        gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(succ_wadm);
        msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
        sprintf(msg, "Plante modifiée avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
    }
}

void on_buttonvalsup_gpl_clicked(GtkButton *button,
                                 gpointer user_data)
{
    char fich[20];
    strcpy(fich, "plantes.txt");
    PLANTE s;
    GtkWidget *id;
    GtkWidget *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    id = lookup_widget(button, "cbidmod_gpl");
    suppPl(gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)), fich);

    succ_wadm = create_succ_wadm();
    gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Suppression");
    gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(succ_wadm);
    msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
    sprintf(msg, "Plante supprimée!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
}

void on_buttonretmod_gpl_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *gestionPlantation;
    GtkWidget *modifsup_gpl;

    modifsup_gpl = lookup_widget(button, "modifsup_gpl");
    gtk_widget_destroy(modifsup_gpl);

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gestionPlantation = create_gestionPlantation();
    gtk_window_set_position(GTK_WINDOW(gestionPlantation), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionPlantation);
}
void on_buttonaj_gpl_clicked(GtkButton *button,
                             gpointer user_data)
{
    GtkWidget *gestionPlantation;
    GtkWidget *ajout_gpl;

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gtk_widget_destroy(gestionPlantation);

    ajout_gpl = create_ajout_gpl();
    gtk_window_set_position(GTK_WINDOW(ajout_gpl), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(ajout_gpl);
}

void on_buttonmodsup_gpl_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *gestionPlantation;
    GtkWidget *modifsup_gpl;

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gtk_widget_destroy(gestionPlantation);

    modifsup_gpl = create_modifsup_gpl();
    gtk_window_set_position(GTK_WINDOW(modifsup_gpl), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(modifsup_gpl);
}

void on_buttonaff_gpl_clicked(GtkButton *button,
                              gpointer user_data)
{
    GtkWidget *gestionPlantation;
    GtkWidget *aff_gpl;

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gtk_widget_destroy(gestionPlantation);

    aff_gpl = lookup_widget(button, "aff_gpl");
    aff_gpl = create_aff_gpl();
    gtk_window_set_position(GTK_WINDOW(aff_gpl), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(aff_gpl);
}

void on_buttoncal_gpl_clicked(GtkButton *button,
                              gpointer user_data)
{
}

void on_buttongequi_ee_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *GestionEquipement;
    GtkWidget *InterEmp;

    InterEmp = lookup_widget(button, "InterEmp");
    gtk_widget_destroy(InterEmp);

    GestionEquipement = create_GestionEquipement();
    gtk_window_set_position(GTK_WINDOW(GestionEquipement), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(GestionEquipement);
}

void on_buttongtroup_ee_clicked(GtkButton *button,
                                gpointer user_data)
{
	GtkWidget *maintroupeaux;	
    GtkWidget *InterEmp;

       InterEmp = lookup_widget(button, "InterEmp");
        gtk_widget_destroy(InterEmp);
	maintroupeaux = lookup_widget(button, "maintroupeaux");
        maintroupeaux = create_maintroupeaux();
        gtk_widget_show(maintroupeaux);

}

void on_buttongclients_ee_clicked(GtkButton *button,
                                  gpointer user_data)
{
GtkWidget *gestionclient;	
    GtkWidget *InterEmp;

       InterEmp = lookup_widget(button, "InterEmp");
        gtk_widget_destroy(InterEmp);
	gestionclient = lookup_widget(button, "gestionclient");
        gestionclient = create_gestionclient();
        gtk_widget_show(gestionclient);

}

void on_buttongcapts_ee_clicked(GtkButton *button,
                                gpointer user_data)
{
GtkWidget *InterEmp;
GtkWidget *windowPrincipaleMES;
windowPrincipaleMES=lookup_widget(button, "windowPrincipaleMES");
InterEmp=lookup_widget(button, "InterEmp");
gtk_widget_destroy(InterEmp);

windowPrincipaleMES = create_windowPrincipaleMES();
gtk_widget_show(windowPrincipaleMES);
}
void on_checkouv_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
}

void on_checkemp_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
}

void on_checkadm_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
}

void on_checkouv_wemp_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
}

void on_checkemp_wemp_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
}

void on_checkempabs_wadm_toggled(GtkToggleButton *togglebutton,
                                 gpointer user_data)
{
}

void on_checkouvabs_wadm_toggled(GtkToggleButton *togglebutton, gpointer user_data)
{
}

//-----------------------------------------GestionCapteurs-------------------------------------//
int r,act;
int t[3]={0,0,0};
act = 0;
void
on_buttonAjouterCapteur_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
    cap c;
    int test;
    GtkWidget *reff,*emp,*marque,*type,*etat,*windowexiste,*windowdone,*GestionCapteurAct;;

    reff =lookup_widget(button,"entryAjouterReference");
    emp = lookup_widget(button,"entryAjouterEmplacement");
    marque = lookup_widget (button,"comboboxMarCap");

    type = lookup_widget (button,"comboboxAjouterType");
    etat = lookup_widget (button,"spinbuttonAjouterEtat");

    strcpy(c.ref, gtk_entry_get_text(GTK_ENTRY(reff)));
    strcpy(c.emp, gtk_entry_get_text(GTK_ENTRY(emp)));
    strcpy(c.marq, gtk_combo_box_get_active_text(GTK_COMBO_BOX(marque)));
    strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
    c.etat=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(etat));

    test=verifier_ref(c.ref);
    if (test==0)
    {
        ajouter_capteur(c);
        windowdone=create_WindowDoneMES(); 
        gtk_widget_show(windowdone);
    }
    else
    {
        windowexiste=create_WindowExisteMES();
        gtk_widget_show(windowexiste);
    }
}   


void
on_buttonModifierCapteur_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *reff,*emp,*marque,*type,*etat,*windowdone;;
    cap c;

    reff = lookup_widget (button,"comboboxModCapdyn");
    emp = lookup_widget(button,"entryModifierEmplacement");
    marque = lookup_widget (button,"combobox3MarModCap");

    type = lookup_widget (button,"comboboxModifierType");
    etat = lookup_widget (button,"spinbuttonModifierEtat");

  //strcpy(c.ref, gtk_entry_get_text(GTK_ENTRY(reff)));
    strcpy(c.ref, gtk_combo_box_get_active_text(GTK_COMBO_BOX(reff)));
    strcpy(c.emp, gtk_entry_get_text(GTK_ENTRY(emp)));
    strcpy(c.marq, gtk_combo_box_get_active_text(GTK_COMBO_BOX(marque)));
    strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
    c.etat=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(etat));
    
    
    modifier_capteur(c);
    windowdone=create_WindowDoneMES(); 
    gtk_widget_show(windowdone);
}


void
on_buttonSupprimerCapteur_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *reff,*windowexiste,*windowNA,*windowdone;
    char ref[20];
    int test;
    reff = lookup_widget (button,"comboboxSupCap");
    strcpy(ref, gtk_combo_box_get_active_text(GTK_COMBO_BOX(reff)));
    test=verifier_ref(ref);
    if (test==0)
    {
        windowNA=create_WindowIntrouvMES();
        gtk_widget_show(windowNA);
    }
    else
    {
        supprimer_capteur(ref);
        windowdone=create_WindowDoneMES();
        gtk_widget_show(windowdone);
    }
}

void
on_buttonRechercherCapteur_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
    cap c;
    GtkWidget *reff,*windowexiste,*windowNA,*output;
    char ref[20];
    int test;
    reff = lookup_widget (button,"entryRechercherReference");
    strcpy(ref, gtk_entry_get_text(GTK_ENTRY(reff)));
    test=verifier_ref(ref);
    if (test==0)
    {
        windowNA=create_WindowIntrouvMES();
        gtk_widget_show(windowNA);
    }
    else
    {
        c=rechercher_capteur(ref);
        char buf[200];
        output = lookup_widget(button, "labelRechercherCapMES");
        snprintf(buf, sizeof buf, "Reference : %s || Type : %s || Emplacement : %s || Marque : %s   || Etat : %d \n", c.ref,c.type,c.emp,c.marq,c.etat);
        gtk_label_set_text(GTK_LABEL(output),buf);
    }
}

void
on_buttonModifierVerifier_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *reff,*windowexiste,*windowNA;
    char ref[20];
    int test;
    reff = lookup_widget (button,"entryModifierReference");
    strcpy(ref, gtk_entry_get_text(GTK_ENTRY(reff)));
    test=verifier_ref(ref);
    if (test==0)
    {
        windowNA=create_WindowIntrouvMES();
        gtk_widget_show(windowNA);
    }
    else
    {
        windowexiste=create_WindowExisteMES();
        gtk_widget_show(windowexiste);
    }
}



void
on_buttonDonAjoCap_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
don d;
    int test;
    GtkWidget *re,*ma,*jo,*mo,*an,*va,*dateDonnee,*windowexiste,*windowdone;;

    re =lookup_widget(button,"comboboxRefDonMES");
    ma =lookup_widget(button,"comboboxMarDonCap");
    dateDonnee = lookup_widget(button, "calendarDonCap");
   
  /*jo = lookup_widget(button,"entryDonJouCap");
    mo = lookup_widget (button,"entryDonMoiCap");
    an = lookup_widget (button,"entryDonAnnCap");*/
    va = lookup_widget (button,"spinbuttonDonValCap");

strcpy(d.ref,gtk_combo_box_get_active_text(GTK_COMBO_BOX(re)));
strcpy(d.marque,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ma)));
gtk_calendar_get_date(GTK_CALENDAR(dateDonnee), &d.annee, &d.mois,&d.jour); //&
d.valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(va));
    /*strcpy(d.jour, gtk_entry_get_text(GTK_ENTRY(jo)));
    strcpy(d.mois, gtk_entry_get_text(GTK_ENTRY(mo)));
    strcpy(d.annee, gtk_entry_get_text(GTK_ENTRY(an)));*/
    
/*char v[100], c[200];
    strcpy(v, gtk_entry_get_text(GTK_ENTRY(valeur)));
snprintf(c,"%s\n", v);
    d.valeur=(int)v; */

ajouter_donnee(d);
        windowdone=create_WindowDoneMES(); 
        gtk_widget_show(windowdone);
}
void
on_treeviewListeCapteurs_row_activated (GtkTreeView     *treeviewListeCapteurs,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
    cap c;
    GtkTreeIter iter;
    gchar *reference;
    gchar *type;
    gchar *emplacement;
    gchar *marquec;
    gint *etat;
    

    GtkTreeModel *model = gtk_tree_view_get_model(treeviewListeCapteurs);
    if (gtk_tree_model_get_iter(model, &iter, path))
    {
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &reference, 1, &type, 2, &emplacement, 3, &marquec, 4, &etat, -1);
        strcpy(c.ref, reference);
        strcpy(c.type, type);

        strcpy(c.emp, emplacement);
        strcpy(c.marq, marquec);
        c.etat = etat;
    supprimer_capteur(c.ref);
    supprimer_donneeCapteur(c.ref);   
    }
}

void
on_buttonConsulterCapteur_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher;
GtkWidget *treeviewListeCapteurs;

    fenetre_afficher = lookup_widget(button, "GestionCapteur");
    treeviewListeCapteurs = lookup_widget(fenetre_afficher, "treeviewListeCapteurs");
    gtk_widget_show(fenetre_afficher);
    consulter_capteur(treeviewListeCapteurs);
}
void
on_treeviewListeDonnees_row_activated  (GtkTreeView     *treeviewListeDonnees,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
don d;
    GtkTreeIter iter;
    gchar *reference;
    gchar *marque;
    gint *jour;
    gint *mois;
    gint *annee;
    gint *valeur;
    

    GtkTreeModel *model = gtk_tree_view_get_model(treeviewListeDonnees);
    if (gtk_tree_model_get_iter(model, &iter, path))
    {
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &reference,1, &marque, 2, &jour, 3, &mois, 4, &annee, 5, &valeur, -1);
        strcpy(d.ref,reference);
	strcpy(d.marque,marque);
        //strcpy(d.ref, reference);
d.jour = jour;
d.mois = mois;
d.annee = annee;
        //strcpy(d.mois,mois);
        //strcpy(d.annee,annee);
        d.valeur = valeur;
    //supprimer_donneeCapteur(d.ref);  
    }
}

void
on_buttonConsulterDonnee_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher;
GtkWidget *treeviewListeDonnees;

    fenetre_afficher = lookup_widget(button, "GestionCapteur");
    treeviewListeDonnees = lookup_widget(fenetre_afficher, "treeviewListeDonnees");
    gtk_widget_show(fenetre_afficher);
    consulter_donnee(treeviewListeDonnees);
}

GtkWidget *GestionCapteurr;
void
on_buttonQuitter_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *InterEmp;
GtkWidget *windowPrincipaleMES;
windowPrincipaleMES=lookup_widget(button, "windowPrincipaleMES");
InterEmp=lookup_widget(button, "InterEmp");
gtk_widget_destroy(windowPrincipaleMES);

InterEmp = create_InterEmp();
gtk_widget_show(InterEmp);
}

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

//gtk_widget_destroy(GTK_WIDGET(GestionCapteurr));
GtkWidget *windowPrincipaleMES;
windowPrincipaleMES=lookup_widget(button, "windowPrincipaleMES");
gtk_widget_destroy(windowPrincipaleMES);
GestionCapteurr = create_GestionCapteur ();

gtk_widget_show (GestionCapteurr);

}




void
on_buttonAct1MES_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_destroy(GestionCapteurr);
GestionCapteurr = create_GestionCapteur ();
gtk_widget_show (GestionCapteurr);
}


void
on_buttonAct2MES_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_destroy(GestionCapteurr);
GestionCapteurr = create_GestionCapteur ();
gtk_widget_show (GestionCapteurr);
}


void
on_buttonQuitterCap_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowPrincipaleMES;
GtkWidget *GestionCapteur;
GestionCapteur=lookup_widget(button, "GestionCapteur");
windowPrincipaleMES=lookup_widget(button, "windowPrincipaleMES");
gtk_widget_destroy(GestionCapteur);

windowPrincipaleMES = create_windowPrincipaleMES();
gtk_widget_show(windowPrincipaleMES);

}

/////////////////////////////////////////////////TACHE 2////////////////////////////////////////////////////////////

//-------------------------------------radio button pour types de capteurs----------------------------------------//
void
on_radiobuttonAlerteTemperature_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{r=1;}
}


void
on_radiobuttonAlerteHumidite_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{r=2;}
}

//-------------------------------------check button zone d'action----------------------------------------//
void
on_checkbuttonAlerteFiable_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{t[0]=1;
t[1]=0;
t[2]=0;}
}


void
on_checkbuttonAlerteAttention_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{t[1]=1;
t[0]=0;
t[2]=0;}
}

void
on_checkbuttonAlerteDanger_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{t[2]=1;
t[1]=0;
t[0]=0;}
}

//-----------------------------les compteurs des pannes et des valeur inacceptables--------------------------------//
void
on_buttonAlerteCapteur_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
	don d;
	cap c;
	GtkWidget *windowAttentionMES, *windowDangerMES, *output, *reff, *vall, *vaM; //*valeur
	char texte1[100]="";
	char texte2[100]="";
	char texte3[100]="";
	FILE * f1=NULL;
	FILE * f=NULL;
	char xxx[20];
	int vvv,vam,vmax,vmin;
	int vamm=0;
        //--------------------- LES COMPTEURS ----------------------------//
	int da=0; //nombre de valeur hors intervalle de l'appareille ayant la ref
	int pa=0; //nombre de capteur en panne de meme type que le capteur ayant la ref
	int dt=0; //nombre de capteur de meme type que le capteur ayant la ref
	int vr=0; //nombre de valeur hors intervalle de tous les appareilles
	int pam1=0; //nombre de alerte marque 1
	int pam2=0; //nombre de alertes marque 2
	int pam3=0; //nombre de alertes marque 3
	int tot=0; //totale de pannes des 3 marques


	int dh=0;
output = lookup_widget(button, "labelAlertePanneMarque");
gtk_label_set_text(GTK_LABEL(output),"");
output = lookup_widget(button, "labelAlerteMaxMin");
gtk_label_set_text(GTK_LABEL(output),"");
reff =lookup_widget(button,"comboboxRefAleMES");
strcpy(d.ref,gtk_combo_box_get_active_text(GTK_COMBO_BOX(reff)));
vall = lookup_widget (button,"spinbuttonAleValCap");
d.valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(vall));
vaM = lookup_widget (button,"spinbutton__");
vamm=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(vaM));


strcpy(xxx,d.ref);
vvv=d.valeur;
vmax=vvv+vamm;
vmin=vvv-vamm;
 ////////
f1=fopen("capteur.txt","a+");
if(r!=2)
{
strcpy(texte1,"capteur de temperature");
}
else
{
strcpy(texte1,"capteur d'humidite");
}

f=fopen("donnee.txt","a+");
if (f!=NULL)
    { 
	while (fscanf(f, "%s %s %d %d %d %d\n", d.ref, d.marque, &d.jour, &d.mois, &d.annee, &d.valeur) != EOF) 
        {
	    if((d.valeur<vmin)||(d.valeur>vmax))
	    {
	    if(strcmp(d.marque,"marque1")==0) pam1++;
            if(strcmp(d.marque,"marque2")==0) pam2++;
            if(strcmp(d.marque,"marque3")==0) pam3++;
	    vr++;
	    }	
            if((strcmp(d.ref,xxx)==0)&&((d.valeur<vmin)||(d.valeur>vmax)))
            {
		da++;
            }
        }
	
    }
while (fscanf(f1, "%s %s %s %s %d\n", c.ref, c.type, c.emp, c.marq, &c.etat) != EOF) 
{	
	if(r!=2)
	{		
      		if(strcmp(c.type,"Temperature")==0)
         	{
	 	dt++;
	   	if(c.etat==0) pa++;
         	}
	}
	else 
	{
		if(strcmp(c.type,"Humidité")==0)
         	{ 
	 	dt++;
		if(c.etat==0) pa++;
         	}
	}
/*if((strcmp(c.marq,"marque1")==0)&&(c.etat==0)) pam1++;
if((strcmp(c.marq,"marque2")==0)&&(c.etat==0)) pam2++;
if((strcmp(c.marq,"marque3")==0)&&(c.etat==0)) pam3++;*/
if(c.etat==0) tot++;
}              
    fclose(f);
    fclose(f1);

if((da>=1)&&(da<=2))
{
windowAttentionMES=create_windowAttentionMES();
gtk_widget_show(windowAttentionMES);
}
else if(da>2)
{
windowDangerMES=create_windowDangerMES();
gtk_widget_show(windowDangerMES);
}
	if(t[0]==1)
	{
	/*windowAttentionMES=create_windowAttentionMES();
	gtk_widget_show(windowAttentionMES);
	windowDangerMES=create_windowDangerMES();
	gtk_widget_show(windowDangerMES);*/
sprintf(texte3,"%s/ ref: %s/ %d alerte\n\nil y a %d capteurs du meme type dont %d en pannes\n",texte1, xxx, da, dt, pa);
output = lookup_widget(button, "labelAlerteMaxMin");
gtk_label_set_text(GTK_LABEL(output),texte3);
sprintf(texte2,"totale %d pannes et %d mesures fausse:\nmarque1: %d mesures/ marque2: %d mesures/ marque3: %d mesures",tot,vr, pam1, pam2, pam3);
output = lookup_widget(button, "labelAlertePanneMarque");
gtk_label_set_text(GTK_LABEL(output),texte2);
	}
	if(t[1]==1)
	{
	/*windowAttentionMES=create_windowAttentionMES();
	gtk_widget_show(windowAttentionMES);*/
	sprintf(texte3,"%s/ ref: %s/ %d alerte\n\nil y a %d capteurs du meme type dont %d en pannes\n",texte1, xxx, da, dt, pa);
output = lookup_widget(button, "labelAlerteMaxMin");
gtk_label_set_text(GTK_LABEL(output),texte3);
	}
	if(t[2]==1)
	{
	/*windowDangerMES=create_windowDangerMES();
	gtk_widget_show(windowDangerMES);*/

sprintf(texte2,"totale %d pannes et %d mesure fausse:\nmarque1: %d mesures/ marque2: %d mesures/ marque3: %d mesures",tot,vr, pam1, pam2, pam3);
output = lookup_widget(button, "labelAlerteMaxMin");
gtk_label_set_text(GTK_LABEL(output),texte2);
	}
//f=fopen("alerte.txt","a+");
dt=0;
}

/*#######################/GESTION DES EQUIPEMENTS/#######################*/

int x=0;

void
on_buttonAjouterWBF_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
    Equi E;
    int test;
    char ty[20];
    GtkWidget *reff,*nom,*marque,*type,*quant,*dialogExisteWBF,*dialogReussieWBF,*windowGestion;;

    reff =lookup_widget(button,"entryAjouterRefWBF");
    nom = lookup_widget(button,"entryAjouterNomWBF");
    marque = lookup_widget (button,"entryAjouterMarqueWBF");
    quant = lookup_widget (button,"spinbuttonAjouterQuantiteWBF");

    strcpy(E.ref, gtk_entry_get_text(GTK_ENTRY(reff)));
    strcpy(E.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
    strcpy(E.marq, gtk_entry_get_text(GTK_ENTRY(marque)));
    E.quant=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(quant));
    switch (x)
    {
    case 1:
        strcpy(E.type,"Produit");
        break;
    case 2:
        strcpy(E.type,"Materiel");
        break;
    case 3:
        strcpy(E.type,"Machine");
        break;
    case 4:
        strcpy(E.type,"Vehecule");
        break;    
    default:
        strcpy(E.type,"Produit");
        break;
    }
    
    //strcpy(E.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
    test=verifier_ref(E.ref);
    if (test==0)
    {
        ajouter_e(E);
        windowGestion=lookup_widget(button,"GestionEquipement");
        gtk_widget_destroy(windowGestion);
        windowGestion=create_GestionEquipement();
        gtk_widget_show(windowGestion);
        dialogReussieWBF=create_dialogReussieWBF();
        gtk_widget_show(dialogReussieWBF);

    }
    else
    {
        dialogExisteWBF=create_dialogExisteWBF();
        gtk_widget_show(dialogExisteWBF);
    }
}   



void
on_buttonModifierWBF_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *reff,*nom,*marque,*type,*quant,*dialogReussieWBF,*windowGestion;
    Equi E;
    
    reff = lookup_widget (button,"comboboxModifierRefWBF");
    nom = lookup_widget(button,"entryModifierNomWBF");
    marque = lookup_widget (button,"entryModifierMarqueWBF");

    type = lookup_widget (button,"comboboxModifierTypeWBF");
    quant = lookup_widget (button,"spinbuttonModifierQuantiteWBF");

    strcpy(E.ref, gtk_combo_box_get_active_text(GTK_COMBO_BOX(reff)));

    //
    strcpy(E.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
    strcpy(E.marq, gtk_entry_get_text(GTK_ENTRY(marque)));
    E.quant=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(quant));
    strcpy(E.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
    
    modifier_e(E);
    
    windowGestion=lookup_widget(button,"GestionEquipement");
    gtk_widget_destroy(windowGestion);
    windowGestion=create_GestionEquipement();
    gtk_widget_show(windowGestion);
    dialogReussieWBF=create_dialogReussieWBF();
    gtk_widget_show(dialogReussieWBF);
}


void
on_buttonSupprimerWBF_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *reff,*windowexiste,*windowNA,*dialogReussieWBF,*windowGestion;
    
    char ref[20];
    reff = lookup_widget (button,"comboboxSupprimerRefWBF");
    strcpy(ref, gtk_combo_box_get_active_text(GTK_COMBO_BOX(reff)));

    supprimer_e(ref);
    
    
    windowGestion=lookup_widget(button,"GestionEquipement");
    gtk_widget_destroy(windowGestion);
    windowGestion=create_GestionEquipement();
    gtk_widget_show(windowGestion);

    dialogReussieWBF=create_dialogReussieWBF();
    gtk_widget_show(dialogReussieWBF);

}


void
on_buttonConsulterWBF_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *treeview,*windowGestion,*windowAfficher;
    windowGestion=lookup_widget(button,"GestionEquipement");
    gtk_widget_destroy(windowGestion);
    windowAfficher=lookup_widget(button,"AfficherEquipement");
    windowAfficher=create_AfficherEquipement();
    gtk_widget_show(windowAfficher);
    treeview=lookup_widget(windowAfficher,"treeviewListeEquipements");
    consulter_e(treeview);
}


void
on_buttonRechercherWBF_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
    Equi E;
    GtkWidget *reff,*windowexiste,*windowNA,*output;
    char ref[20];
    int test;
    reff = lookup_widget (button,"entryRechercher");
    strcpy(ref, gtk_entry_get_text(GTK_ENTRY(reff)));
    test=verifier_refe(ref);
    if (test==0)
    {
        windowNA=create_WindowNA();
        gtk_widget_show(windowNA);
    }
    else
    {
        E=rechercher_e(ref);
        char buf[200];
        output = lookup_widget(button, "labelRechercherWBF");
        snprintf(buf, sizeof buf, "Reference : %s || Nom : %s || Quantites : %d || Type : %s || Marque : %s \n", E.ref,E.nom,E.quant,E.type,E.marq);
        gtk_label_set_text(GTK_LABEL(output),buf);
    }
}

void
on_buttonModifierAfficherWBF_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{
    char ref[20];
    GtkWidget *reff,*nom,*marque,*type,*quant,*windowdone;;
    Equi E;
    
    reff = lookup_widget (button,"comboboxModifierRefWBF");
    nom = lookup_widget(button,"entryModifierNomWBF");
    marque = lookup_widget (button,"entryModifierMarqueWBF");
    type = lookup_widget (button,"comboboxModifierTypeWBF");
    quant = lookup_widget (button,"spinbuttonModifierQuantiteWBF");
    strcpy(ref, gtk_combo_box_get_active_text(GTK_COMBO_BOX(reff)));
    E=rechercher_e(ref);
    gtk_entry_set_text(GTK_ENTRY(nom),E.nom);
    gtk_entry_set_text(GTK_ENTRY(marque),E.marq);
    if((strcmp(E.type,"Produit")==0))
    {
        gtk_combo_box_set_active(GTK_COMBO_BOX(type),0);
    }
    if((strcmp(E.type,"Materiel")==0))
    {
        gtk_combo_box_set_active(GTK_COMBO_BOX(type),1);
    }
    if((strcmp(E.type,"Vehecule")==0))
    {
        gtk_combo_box_set_active(GTK_COMBO_BOX(type),2);
    }
    if((strcmp(E.type,"Machine")==0))
    {
        gtk_combo_box_set_active(GTK_COMBO_BOX(type),3);
    }
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(quant),E.quant);

    
}


void
on_buttonRetourTreeWBF_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *windowGestion,*windowAfficher;
    windowAfficher=lookup_widget(button,"AfficherEquipement");
    gtk_widget_destroy(windowAfficher);
    windowGestion=create_GestionEquipement();
    gtk_widget_show(windowGestion);
}


void
on_treeviewListeEquipements_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
    GtkTreeIter iter;
    GtkWidget *windowGestion,*windowAfficher;
    gchar *ref,*nom,*marque,*type,*quant;
    Equi E;
    GtkTreeModel *model = gtk_tree_view_get_model(treeview);
    if (gtk_tree_model_get_iter(model,&iter,path))
    {
        gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&ref,1,&nom,2,&marque,3,&type,4,&quant,-1);
        strcpy(E.ref,ref);
        //strcpy(E.nom,nom);
        //strcpy(E.marq,marque);
        //strcpy(E.type,type);
        E.quant=quant;
        supprimer_e(E.ref);
        
        windowAfficher=create_AfficherEquipement();
        gtk_widget_destroy(windowAfficher);
        gtk_widget_show(windowAfficher);
        treeview=lookup_widget(windowAfficher,"treeviewListeEquipements");
        consulter_e(treeview);
    }
}


void
on_buttonUpdateWBF_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *treeview,*windowGestion,*windowAfficher;
    windowAfficher=lookup_widget(button,"AfficherEquipement");
    gtk_widget_destroy(windowAfficher);
    windowAfficher=create_AfficherEquipement();
    gtk_widget_show(windowAfficher);
    treeview=lookup_widget(windowAfficher,"treeviewListeEquipements");
    consulter_e(treeview);
}


void
on_radiobuttonTypeProduitWBF_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        x=1;
    }
}


void
on_radiobuttonTypeMaterielWBF_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        x=2;
    }
}


void
on_radiobuttonTypeMachineWBF_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        x=3;
    }
}


void
on_radiobuttonTypeVeheculeWBF_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        x=4;
    }
}

void
on_buttonDeconexionWBF_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *GestionEquipement;
    GtkWidget *Authentification;

    GestionEquipement = lookup_widget(button, "GestionEquipement");
    gtk_widget_destroy(GestionEquipement);

    Authentification = create_Authentification();
    gtk_window_set_position(GTK_WINDOW(Authentification), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(Authentification);
}


void
on_buttonRetourMenuWBF_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *GestionEquipement;
    GtkWidget *InterEmp;

    GestionEquipement = lookup_widget(button, "GestionEquipement");
    gtk_widget_destroy(GestionEquipement);

    InterEmp = create_InterEmp();
    gtk_window_set_position(GTK_WINDOW(InterEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(InterEmp);
}


void
on_okbuttonReussieWBF_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *GestionEquipement;
    GtkWidget *dialogReussieWBF;

    dialogReussieWBF = lookup_widget(button, "dialogReussieWBF");
    gtk_widget_destroy(dialogReussieWBF);
}


void
on_okbuttonExisteWBF_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *GestionEquipement;
    GtkWidget *dialogExisteWBF;

    dialogExisteWBF = lookup_widget(button, "dialogExisteWBF");
    gtk_widget_destroy(dialogExisteWBF);
}



/*#######################/GESTION DES TROUPEAUX/#######################*/

int x,x1;

void
on_ajoutertroupeaux_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *ajouttroupeaux;
	ajouttroupeaux=create_ajouttroupeaux();
        gtk_window_set_position(GTK_WINDOW(ajouttroupeaux), GTK_WIN_POS_CENTER_ALWAYS);
	gtk_widget_show(ajouttroupeaux);
}


void
on_radiobuttonmalletroupeaux_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=2;
	}
}


void
on_radiobuttonfemelletroupeaux_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=1;
	}
}


void
on_buttonretourajouttroupeau_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *windowajouttroupeau;

	windowajouttroupeau = lookup_widget(button, "ajouttroupeaux");
	gtk_widget_destroy(windowajouttroupeau);
}


void
on_buttonajoutconfirmertroupeaux_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	troupeau t;
	char msg[50];
	GtkWidget *input1,*input3,*input4,*input5,*input6;
	GtkWidget *info,*ajouttroupeaux,*succesajouttroupeau;
	ajouttroupeaux=create_ajouttroupeaux();	
	
	input1 = lookup_widget(button, "entry1identifianttroupeaux");
	input3 = lookup_widget(button, "spinbutton1");
	input4 = lookup_widget(button, "spinbutton2");
	input5 = lookup_widget(button, "spinbutton3");
	input6 = lookup_widget(button, "combobox1typetroupeaux");
	
	strcpy(t.identifiant, gtk_entry_get_text(GTK_ENTRY(input1)));
	if(x==1){
		strcpy(t.sexe,"femelle");
	}
	else{
		if(x==2){
			strcpy(t.sexe,"male");
		} 
	}       
	t.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));
	t.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
	t.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
	strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));
	/*if(veriftroupeau(t)==1){
	        info = lookup_widget(ajouttroupeaux, "label238");
		snprintf(msg, sizeof msg , "identifiant deja existant!!");
        	gtk_label_set_text(GTK_LABEL(info),msg);  
	}*/
	//else {
	ajouter(t);
	succesajouttroupeau=create_succesajouttroupeau();
        gtk_window_set_position(GTK_WINDOW(succesajouttroupeau), GTK_WIN_POS_CENTER_ALWAYS);
	gtk_widget_show(succesajouttroupeau);
	//}
}

void
on_buttoncherchertroupeaux_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
	troupeau t;
	FILE *f = NULL;	
	char ch[20],s[200];
	GtkWidget *input; 
	GtkWidget *info;
	GtkWidget *windowaffichertroupeaux;
	windowaffichertroupeaux=create_affichagetroupeau();
	gtk_widget_show(windowaffichertroupeaux);
	input = lookup_widget(button, "entryrecherchertroupeau");
	strcpy(ch, gtk_entry_get_text(GTK_ENTRY(input)));
	t=chercher(ch);
	f=fopen("test.txt","a+");
	fprintf(f,"%s %s %d %d %d %s \n", t.identifiant, t.sexe, t.jour, t.mois, t.annee, t.type);
	fclose(f);
	info = lookup_widget(windowaffichertroupeaux, "labelaffichertroupeau");
	snprintf(s, sizeof s , "sexe:  %s | type: %s | date de naissance: %d/%d/%d",t.sexe, t.type,t.jour,t.mois,t.annee);
        gtk_label_set_text(GTK_LABEL(info),s);
}


void
on_retouraffichagetroupeau_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affichagetroupeau;
	remove("test.txt");
	affichagetroupeau = lookup_widget(button, "affichagetroupeau");
	gtk_widget_destroy(affichagetroupeau);
}


void
on_treeviewveau_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
        gchar *identifiant;
        gchar *sexe;
        gchar *jour;
        gchar *mois;
        gchar *annee;
        gchar *type;
	GtkWidget *IDENTIFIANT, *SEXE, *JOUR, *MOIS, *ANNEE, *TYPE;
	troupeau t;
	GtkWidget *maintroupeau;
	FILE *f = NULL, *fV = NULL;
	f = fopen("troupeauxrs.txt", "r");
   	fV = fopen("veau.txt", "w");

	if ((f != NULL) && (fV != NULL) )
	{
        	while (fscanf(f, "%s %s %d %d %d %s \n", t.identifiant, t.sexe, t.jour, t.mois, t.annee, t.type) != EOF){
            		if (strcmp(t.type, "veau") == 0){
                		fprintf(fV, "%s %s %d %d %d %s \n", t.identifiant, t.sexe, t.jour, t.mois, t.annee, t.type);
            		}         
        	}
	}
	fclose(f);
	fclose(fV);
	maintroupeau = lookup_widget(treeview, "maintroupeaux");
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter, path)){
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &identifiant, 1, &sexe,2,&jour,3,&mois,4,&annee,5,&type, -1);
        strcpy(t.identifiant, identifiant);
        strcpy(t.sexe, sexe);
        strcpy(t.jour, jour);
        strcpy(t.mois, mois);
        strcpy(t.annee, annee);
        strcpy(t.type, type);
	}
	//remove("veau.txt");
}


void
on_treeviewbrebi_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
        gchar *identifiant;
        gchar *sexe;
        gchar *jour;
        gchar *mois;
        gchar *annee;
        gchar *type;
	GtkWidget *IDENTIFIANT, *SEXE, *JOUR, *MOIS, *ANNEE, *TYPE;
	troupeau t;
	char ln[10];
	GtkWidget *maintroupeau;
	FILE *f = NULL, *fB = NULL, *ftempob = NULL;
	strcpy(ln,"brebi");
	f = fopen("troupeauxrs.txt", "r");
   	fB = fopen("brebi.txt", "w");	

	if ((f != NULL) && (fB != NULL))
	{
        	while (fscanf(f, "%s %s %d %d %d %s \n", t.identifiant, t.sexe, t.jour, t.mois, t.annee, t.type) != EOF){
            		if (strcmp(t.type, ln) == 0){
                		fprintf(fB, "%s %s %d %d %d %s \n", t.identifiant, t.sexe, t.jour, t.mois, t.annee, t.type);
            		}        
        	}
	}
	fclose(f);
	fclose(fB);
	maintroupeau = lookup_widget(treeview, "maintroupeaux");
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter, path))
	{
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &identifiant, 1, &sexe,2,&jour,3,&mois,4,&annee,5,&type, -1);
        strcpy(t.identifiant, identifiant);
        strcpy(t.sexe, sexe);
	t.jour=jour;
	t.mois=mois;
	t.annee=annee;
        strcpy(t.type, type);
	}
	//remove("brebi.txt");
}


void
on_buttonaffichertroupeau_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *treeview1, *treeview2, *maintroupeaux;
	char affich1[20],affich2[20];
	troupeau t;
	FILE *f = NULL, *fB = NULL, *fV = NULL;
	maintroupeaux = lookup_widget(button, "maintroupeaux");

	f = fopen("troupeauxrs.txt", "r");
	fB = fopen("brebi.txt", "w");
	fV = fopen("veau.txt", "w");	
	if ((f != NULL) && (fB != NULL) && (fV != NULL)){
        	while (fscanf(f, "%s %s %d %d %d %s \n", t.identifiant, t.sexe, &t.jour, &t.mois, &t.annee, t.type) != EOF){
            		if (strcmp(t.type, "brebi") == 0){
                		fprintf(fB, "%s %s %d %d %d %s \n", t.identifiant, t.sexe, t.jour, t.mois, t.annee, t.type);
            			}
            		if (strcmp(t.type, "veau") == 0){
                		fprintf(fV, "%s %s %d %d %d %s \n", t.identifiant, t.sexe, t.jour, t.mois, t.annee, t.type);
            		}           
        	}
	}
	fclose(f);
	fclose(fB);
	fclose(fV);
        strcpy(affich1, "brebi.txt");
        strcpy(affich2, "veau.txt");
	gtk_widget_show(maintroupeaux);
	treeview1 = lookup_widget(maintroupeaux, "treeviewbrebi");
	treeview2 = lookup_widget(maintroupeaux, "treeviewveau");
	affichertroupeau(treeview1, affich1);
	affichertroupeau(treeview2, affich2);
	//remove("brebi.txt");
	//remove("veau.txt");
}


void
on_modifieraffichertroupeau_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *windowmodifiertroupeau;
	windowmodifiertroupeau=create_windowmodifiertroupeau();
        gtk_window_set_position(GTK_WINDOW(windowmodifiertroupeau), GTK_WIN_POS_CENTER_ALWAYS);
	gtk_widget_show(windowmodifiertroupeau);
}


void
on_supptroupeau_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
	FILE *ftest;
	troupeau T;
	char id[20];
	char s[10];
	int j,m,a;
        char ty[10];

	ftest=fopen("test.txt","r");
	fscanf(ftest, "%s %s %d %d %d %s \n",id ,s, &j, &m, &a, ty);
	fclose(ftest);
	strcpy(T.identifiant,id);
	strcpy(T.sexe,s);
	strcpy(T.type,ty);
	supprimertroupeau(T);
	remove("test.txt");
}


void
on_radiobuttonfemellemodifier_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x1=1;
	}
}


void
on_radiobuttonmodifiermale_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x1=2;
	}
}


void
on_buttonmodifiertroupeau_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
	FILE *ftest;
	troupeau T;
	char id[20];
	char s[10];
	int j,m,a;
        char ty[10];
	GtkWidget *input1,*input3,*input4,*input2;

	ftest=fopen("test.txt","r");
	fscanf(ftest, "%s %s %d %d %d %s \n",id ,s, &j, &m, &a, ty);
	fclose(ftest);
	strcpy(T.identifiant,id);

	input1 = lookup_widget(button, "spinbutton4troupeau");
	input2 = lookup_widget(button, "spinbutton5troupeau");
	input3 = lookup_widget(button, "spinbutton6troupeau");
	input4 = lookup_widget(button, "combobox2");
	
	if(x1==1){
		strcpy(T.sexe,"femelle");
	}
	else{
		if(x1==2){
			strcpy(T.sexe,"male");
		} 
	}       
	T.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input1));
	T.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input2));
	T.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));
	strcpy(T.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));

	modifier(T);
	remove("test.txt");
}

void
on_buttonretoursuccestroupeau_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *succesajouttroupeau;

	succesajouttroupeau = lookup_widget(button, "succesajouttroupeau");
	gtk_widget_destroy(succesajouttroupeau);
}


void
on_terminersuccestroupeau_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *succesajouttroupeau,*ajouttroupeaux;

	succesajouttroupeau = lookup_widget(button, "succesajouttroupeau");
	gtk_widget_destroy(succesajouttroupeau);	
	ajouttroupeaux = lookup_widget(button, "ajouttroupeaux");
	gtk_widget_destroy(ajouttroupeaux);
}


void
on_buttonretourinittroupeau_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *maintroupeaux;
        GtkWidget *InterEmp;

	maintroupeaux = lookup_widget(button, "maintroupeaux");
	gtk_widget_destroy(maintroupeaux);
        InterEmp = lookup_widget(button, "InterEmp");
        InterEmp= create_InterEmp();
        gtk_widget_show(InterEmp);
}


void
on_buttonretoursucces2troupeau_clicked (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *successupressiontroupeau;

	successupressiontroupeau = lookup_widget(button, "successupressiontroupeau");
	gtk_widget_destroy(successupressiontroupeau);
}


void
on_nombretroupeau_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *wnombretroupeau;
	int nb=0,nv=0;
	GtkWidget *nombret, *nombreb;
	char sb[8],sv[8];

	nv = nombreveau();
	nb = nombrebrebi();
	wnombretroupeau=create_wnombretroupeau();
        gtk_window_set_position(GTK_WINDOW(wnombretroupeau), GTK_WIN_POS_CENTER_ALWAYS);
	gtk_widget_show(wnombretroupeau);
	nombret = lookup_widget(wnombretroupeau, "label352");
	snprintf(sv, sizeof sv , "%d",nv);
        gtk_label_set_text(GTK_LABEL(nombret),sv);	
	nombreb = lookup_widget(wnombretroupeau, "label355");
	snprintf(sb, sizeof sb , "%d",nb);
        gtk_label_set_text(GTK_LABEL(nombreb),sb);
	
}


void
on_retournombretroupeaux_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *wnombretroupeau;

	wnombretroupeau = lookup_widget(button, "wnombretroupeau");
	gtk_widget_destroy(wnombretroupeau);
}
  

void
on_retoursuccesmodifiertroupeau_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *wsuccesmodiftroupeau;

	wsuccesmodiftroupeau = lookup_widget(button, "wsuccesmodiftroupeau");
	gtk_widget_destroy(wsuccesmodiftroupeau);
}

///////////////////////////partie gestion des clients///////////
int Homme,Femme,ModifierHomme,ModifierFemme;
void
on_buttonModifier_Supprimer_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionclient;
    GtkWidget *modifier;

    gestionclient = lookup_widget(button, "gestionclient");
    gtk_widget_destroy(gestionclient);

    modifier = lookup_widget(button, "modifier");
    modifier = create_modifier();
    gtk_widget_show(modifier);

}


void
on_buttonClientFidele_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionclient;
    GtkWidget *ajoutcf;

    gestionclient = lookup_widget(button, "gestionclient");
    gtk_widget_destroy(gestionclient);

    ajoutcf = lookup_widget(button, "ajoutcf");
    ajoutcf = create_ajoutcf();
    gtk_window_set_position(GTK_WINDOW(ajoutcf), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(ajoutcf);


}


void
on_buttonAjouter_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionclient;
    GtkWidget *ajouter;

    gestionclient = lookup_widget(button, "gestionclient");
    gtk_widget_destroy(gestionclient);

    ajouter = lookup_widget(button, "ajouter");
    ajouter = create_ajouter();
    gtk_window_set_position(GTK_WINDOW(ajouter), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(ajouter);


}





void
on_homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        Homme = 1;
    }

}


void
on_Femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        Femme = 2;
    }

}


void
on_AjouterValider_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
    char fich[20];
    strcpy(fich, "client.txt");
   CLIENT u;
    GtkWidget *cin, *nom, *prenom, *nationalite ,*sexe;
    GtkWidget *output_ajout;
    GtkWidget *ajouter, *Success, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    output_ajout = lookup_widget(button, "outputaj");

    cin = lookup_widget(button, "AjouterCin");
    nom = lookup_widget(button, "AjouterNom");
    prenom = lookup_widget(button, "AjouterPrenom");
    nationalite = lookup_widget(button, "AjouterNationalite");
    if (!verifCin(gtk_entry_get_text(GTK_ENTRY(cin))))
    {
        sprintf(msg, "Le CIN doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (!verifClient(gtk_entry_get_text(GTK_ENTRY(cin)), fich))
    {
        sprintf(msg, "Le client existe déjà!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }

    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        strcpy(u.cin, gtk_entry_get_text(GTK_ENTRY(cin)));
        strcpy(u.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
        strcpy(u.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
        strcpy(u.nationalite, gtk_combo_box_get_active_text(GTK_COMBO_BOX(nationalite)));

        suppEspaces(u.nom);
        suppEspaces(u.prenom);

  
        strcpy(u.sexe, "Homme");
        if (Homme == 1)
        {
            strcpy(u.sexe, "Homme");
        }
        else if (Femme == 2)
        {
            strcpy(u.sexe, "Femme");
        }
        ajoutClient(u, fich);
        ajouter = lookup_widget(button, "ajouter");
        Success = lookup_widget(button, "Success");
        Success = create_Success();
        gtk_window_set_title(GTK_WINDOW(Success), "Success");
        gtk_window_set_position(GTK_WINDOW(Success), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(Success);
        msg_succ = lookup_widget(Success, "rblabelsucc");
        sprintf(msg, "Client ajouté avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);

}
}
/////////////////////////

void
on_AjouterRetour_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionclient;
    GtkWidget *buttonAjouter;

    buttonAjouter = lookup_widget(button, "ajouter");
    gtk_widget_destroy(buttonAjouter);

    gestionclient = lookup_widget(button, "gestionclient");
    gestionclient = create_gestionclient();
    gtk_window_set_position(GTK_WINDOW(gestionclient), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionclient);


}


void
on_ModifierRetour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *gestionclient;
    GtkWidget *modifier;

    modifier = lookup_widget(button, "modifier");
    gtk_widget_destroy(modifier);

    gestionclient = lookup_widget(button, "gestionclient");
    gestionclient = create_gestionclient();
    gtk_window_set_position(GTK_WINDOW(gestionclient), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionclient);

}


void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ModifierCin,*msg_succ,*Success;
char cin[50];
char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
ModifierCin=lookup_widget (button,"ModifierCin");
    strcpy(cin, gtk_entry_get_text(GTK_ENTRY(ModifierCin)));
supprimer(cin);
 
 Success = lookup_widget(button, "Success");
        Success = create_Success();
        gtk_window_set_title(GTK_WINDOW(Success), "Success");
        gtk_window_set_position(GTK_WINDOW(Success), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(Success);
        msg_succ = lookup_widget(Success, "rblabelsucc");
        sprintf(msg, "Client supprimer avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);


}
/////change

void
on_Modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
CLIENT c;
char msg[50], *markup,*msg_succ,*Success;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

  GtkWidget *ModifierNom;
  GtkWidget *ModifierPrenom;
  GtkWidget *ModifierCin;
  GtkWidget *ModifierNationalite;
  GtkWidget *ModifierHomme;
  GtkWidget *ModifierFemme;

  ModifierHomme = lookup_widget(button, "ModifierHomme");
  ModifierFemme = lookup_widget(button, "ModifierFemme");
  ModifierNom = lookup_widget(button, "ModifierNom");
  ModifierPrenom = lookup_widget(button, "ModifierPrenom");
  ModifierCin = lookup_widget(button, "ModifierCin");
  ModifierNationalite = lookup_widget(button, "ModifierNationalite");
  strcpy(c.nom, gtk_entry_get_text(GTK_ENTRY(ModifierNom)));
  strcpy(c.prenom, gtk_entry_get_text(GTK_ENTRY(ModifierPrenom)));
  strcpy(c.cin, gtk_entry_get_text(GTK_ENTRY(ModifierCin)));
  strcpy(c.nationalite, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ModifierNationalite)));

  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ModifierFemme)))
  {
    strcpy(c.sexe, "Femme");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ModifierHomme)))
  {
    strcpy(c.sexe, "Homme");
  }
  modifierclient(c,gtk_entry_get_text(GTK_ENTRY(ModifierCin)));
Success = lookup_widget(button, "Success");
        Success = create_Success();
        gtk_window_set_title(GTK_WINDOW(Success), "Success");
        gtk_window_set_position(GTK_WINDOW(Success), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(Success);
        msg_succ = lookup_widget(Success, "rblabelsucc");
        sprintf(msg, "Client modifier avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);

    }



void
on_TreeviewAfficher_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
CLIENT c;
  GtkTreeIter iter;
  gchar *nom;
  gchar *prenom;
  gchar *cin;
  gchar *nationalite;
  gchar *sexe;
  GtkWidget *afficher;
  GtkWidget *TreeviewAfficher;
  GtkWidget *modifier;
  GtkWidget *NOM;
  GtkWidget *PRENOM;
  GtkWidget *CIN;
  GtkWidget *NATIONALITE;
  GtkWidget *HOMME;
  GtkWidget *FEMME;

  afficher = lookup_widget(TreeviewAfficher, "afficher");
  GtkTreeModel *model = gtk_tree_view_get_model(TreeviewAfficher);
  if (gtk_tree_model_get_iter(model, &iter, path))
 {
    gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &nom, 1, &prenom, 2, &cin, 3, &nationalite , 4, &sexe, -1);
        strcpy(c.cin, cin);
        strcpy(c.nationalite, nationalite);
        strcpy(c.nom, nom);
        strcpy(c.prenom, prenom);
        strcpy(c.sexe, sexe);

    modifier = create_modifier();
    gtk_widget_hide(afficher);
    gtk_widget_show(modifier);

    NOM = lookup_widget(modifier, "ModifierNom");
    PRENOM = lookup_widget(modifier, "ModifierPrenom");
    CIN = lookup_widget(modifier, "ModifierCin");
    NATIONALITE = lookup_widget(modifier, "ModifierNationalite");
    HOMME = lookup_widget(modifier, "ModifierHomme");
    FEMME = lookup_widget(modifier, "ModifierFemme");

    gtk_entry_set_text(GTK_ENTRY(NOM), nom);
    gtk_entry_set_text(GTK_ENTRY(PRENOM), prenom);
    gtk_entry_set_text(GTK_ENTRY(CIN), cin);
    gtk_entry_set_text(GTK_COMBO_BOX(NATIONALITE), nationalite);
    if ((strcmp(c.sexe, "Homme") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 1);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 0);
    }
    else if ((strcmp(c.sexe, "Femme") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 1);
    }
  }
}



void
on_Afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
char fich[20];
 GtkWidget *afficher;
  GtkWidget *TreeviewAfficher;

  afficher = lookup_widget(button, "afficher");
  TreeviewAfficher = lookup_widget(afficher, "TreeviewAfficher");
  gtk_widget_show(afficher);
strcpy(fich, "client.txt");
  affClient(TreeviewAfficher, fich);

}


void
on_AfficherRechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
  CLIENT c;
  GtkWidget *afficher;
  GtkWidget *AfficherCin;
  GtkWidget *TreeviewAfficher;
  FILE *f;
  FILE *f2;
  char cin[30];
//////////////////
  afficher = lookup_widget(button, "afficher");
  AfficherCin = lookup_widget(button, "AfficherCin");
  strcpy(cin, gtk_entry_get_text(GTK_ENTRY(AfficherCin)));
  f = fopen("client.txt", "r");

  if (f != NULL)
  {
    while (fscanf(f, "%s %s %s %s %s  \n", c.nom, c.prenom,c.cin,c.nationalite,c.sexe) != EOF)
    {
      f2 = fopen("temp.txt", "a+");
      if (f2 != NULL)
      {
        if ((strcmp(c.cin, cin) == 0))
        {
          fprintf(f2, "%s %s %s %s %s  \n", c.nom, c.prenom,c.cin,c.nationalite,c.sexe);
        }
        TreeviewAfficher = lookup_widget(afficher, "TreeviewAfficher");
        rechClient(TreeviewAfficher);
        fclose(f2);
      }
    }

    fclose(f);
  }
  remove("temp.txt");

}


void
on_SuccValider_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *gestionclient;
    GtkWidget *Success;

    Success = lookup_widget(button, "Success");
    gtk_widget_destroy(Success);

    gestionclient = lookup_widget(button, "gestionclient");
    gestionclient = create_gestionclient();
    gtk_window_set_position(GTK_WINDOW(gestionclient), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionclient);
}


void
on_ButtonOnView_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_AuthConnexion_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_AuthQuitter_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}






void
on_buttonAfficher_rechercher_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionclient;
    GtkWidget *afficher;

    gestionclient = lookup_widget(button, "gestionclient");
    gtk_widget_destroy(gestionclient);

    afficher = lookup_widget(button, "afficher");
    afficher = create_afficher();
    gtk_window_set_position(GTK_WINDOW(afficher), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(afficher);

}




void
on_afficherretour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *gestionclient;
    GtkWidget *afficher;

    afficher = lookup_widget(button, "afficher");
    gtk_widget_destroy(afficher);

    gestionclient = lookup_widget(button, "gestionclient");
    gestionclient = create_gestionclient();
    gtk_window_set_position(GTK_WINDOW(gestionclient), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionclient);

}


void
on_buttonDeconneter_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *gestionclient;
    GtkWidget *Authentif;

    gestionclient = lookup_widget(button, "gestionclient");
    gtk_widget_destroy(gestionclient);

    Authentif = lookup_widget(button, "Authentif");
    Authentif = create_Authentif();
    gtk_window_set_position(GTK_WINDOW(Authentif), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(Authentif);

}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
CLIENT c;
  GtkTreeIter iter;
  gchar *prix;
  gchar *cin;
  GtkWidget *ClientFidele;
  GtkWidget *treeview1;
  GtkWidget *PRIX;
  GtkWidget *CIN;


  ClientFidele = lookup_widget(treeview1, "ClientFidele");
  GtkTreeModel *model = gtk_tree_view_get_model(treeview1);
  if (gtk_tree_model_get_iter(model, &iter, path))
 {
    gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &cin, 1, &prix, -1);
        strcpy(c.cin, cin);
        strcpy(c.prix, prix);
  }

}


void
on_affichercf_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
char fich[20];
 GtkWidget *ClientFidele;
  GtkWidget *treeview1;

  ClientFidele = lookup_widget(button, "ClientFidele");
  treeview1 = lookup_widget(ClientFidele, "treeview1");
  gtk_widget_show(ClientFidele);
strcpy(fich, "clientfid.txt");
  affClientfid(treeview1, fich);

}


void
on_recherchecf_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}
/////////////////

void
on_buttonaffichercf_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *ClientFidele;
    GtkWidget *ajoutcf;

    ajoutcf = lookup_widget(button, "ajoutcf");
    gtk_widget_destroy(ajoutcf);

    ClientFidele = lookup_widget(button, "ClientFidele");
    ClientFidele = create_ClientFidele();
    gtk_window_set_position(GTK_WINDOW(ClientFidele), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(ClientFidele);

}


void
on_ajoutercf_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
    char fich[20],fich1[20];
    strcpy(fich, "clientfid.txt");
    strcpy(fich1, "client.txt");
   CLIENT u;
    GtkWidget *cin, *prix;
    GtkWidget *output_ajouter;
    GtkWidget *ajoutcf, *Success, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    output_ajouter = lookup_widget(button, "outputajouter");

    cin = lookup_widget(button, "cincf");
    prix = lookup_widget(button, "prixcf");
    if (!verifCin(gtk_entry_get_text(GTK_ENTRY(cin))))
    {
        sprintf(msg, "Le CIN doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajouter), markup);
    }
    else if (!verifClient(gtk_entry_get_text(GTK_ENTRY(cin)), fich1))
    {
        sprintf(msg, "Le client n' existe pas!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajouter), markup);
    }

    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        strcpy(u.cin, gtk_entry_get_text(GTK_ENTRY(cin)));
        strcpy(u.prix, gtk_entry_get_text(GTK_ENTRY(prix)));

///////////////////////////////////////
        ajouterclientfid(u, fich);
        ajoutcf = lookup_widget(button, "ajoutcf");
        Success = lookup_widget(button, "Success");
        Success = create_Success();
        gtk_window_set_title(GTK_WINDOW(Success), "Success");
        gtk_window_set_position(GTK_WINDOW(Success), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(Success);
        msg_succ = lookup_widget(Success, "rblabelsucc");
        sprintf(msg, "Client et achat ajouté avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);

}

}


void
on_retourcf_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *gestionclient;
    GtkWidget *ClientFidele;

    ClientFidele = lookup_widget(button, "ClientFidele");
    gtk_widget_destroy(ClientFidele);

    gestionclient = lookup_widget(button, "gestionclient");
    gestionclient = create_gestionclient();
    gtk_window_set_position(GTK_WINDOW(gestionclient), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionclient);

}


void
on_retourclientfidele_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *gestionclient;
    GtkWidget *ClientFidele;

    ClientFidele = lookup_widget(button, "ClientFidele");
    gtk_widget_destroy(ClientFidele);

    gestionclient = lookup_widget(button, "gestionclient");
    gestionclient = create_gestionclient();
    gtk_window_set_position(GTK_WINDOW(gestionclient), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionclient);

}


void
on_show_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *nom, *prenom, *cin, *sexe, *nationalite, *homme, *femme;
    CLIENT u;
    nom = lookup_widget(button, "ModifierNom");
    prenom = lookup_widget(button, "ModifierPrenom");
    cin = lookup_widget(button, "ModifierCin");
    nationalite = lookup_widget(button, "ModifierNationalite");
    homme = lookup_widget(button, "ModifierHomme");
    femme = lookup_widget(button, "ModifierFemme");
       
    u = recheClient(gtk_entry_get_text(GTK_ENTRY(cin)));
        
        gtk_entry_set_text(GTK_ENTRY(nom), u.nom);
        gtk_entry_set_text(GTK_ENTRY(cin), u.cin);
        gtk_entry_set_text(GTK_ENTRY(prenom), u.prenom);
///////////////
    if((strcmp(u.nationalite,"Tunisienne")==0))
    {
        gtk_combo_box_set_active(GTK_COMBO_BOX(nationalite),0);
    }
    if((strcmp(u.nationalite,"Etrangere")==0))
    {
        gtk_combo_box_set_active(GTK_COMBO_BOX(nationalite),1);
    }
///////////////
       // gtk_combo_box_set_active(GTK_COMBO_BOX(nationalite), u.nationalite);


        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(Homme), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(Femme), 1);
      
        }

}




void
on_actualiserr_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
char fich[20];
    GtkWidget *treeview1,*afficher;
    afficher=lookup_widget(button,"afficher");
    gtk_widget_destroy(afficher);
    afficher=create_afficher();
    gtk_widget_show(afficher);
    treeview1=lookup_widget(afficher,"treeview1");
strcpy(fich, "client.txt");
  affClient(treeview1, fich);

}




void
on_retourgc_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionclient;
    GtkWidget *InterEmp;

    gestionclient = lookup_widget(button, "gestionclient");
    gtk_widget_destroy(gestionclient);

    InterEmp = lookup_widget(button, "InterEmp");
    InterEmp = create_InterEmp();
    gtk_window_set_position(GTK_WINDOW(InterEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(InterEmp);

}


void
on_buttonAfficherdefectWBF_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *outputss;
    FILE *f1;
    cap c;
    int c1=0,c2=0,c3=0,tott=0;
    char textt1[1000];
    f1=fopen("capteur.txt","r");
    if (f1!=NULL){
            while (fscanf(f1, "%s %s %s %s %d\n", c.ref, c.type, c.emp, c.marq, &c.etat) != EOF) 
        {	
	
            if((strcmp(c.marq,"marque1")==0)&&(c.etat==0)) c1++;
            if((strcmp(c.marq,"marque2")==0)&&(c.etat==0)) c2++;
            if((strcmp(c.marq,"marque3")==0)&&(c.etat==0)) c3++;

        }              
    }
	
    fclose(f1);
    tott=c1+c2+c3;
    
    sprintf(textt1,"Totales des pannes : %d \n Marque1: %d|| Marque2 : %d || Marque3 : %d ",tott, c1, c2, c3);
    outputss = lookup_widget(button, "labelaffichedefect");
    gtk_label_set_text(GTK_LABEL(outputss),textt1);
}

