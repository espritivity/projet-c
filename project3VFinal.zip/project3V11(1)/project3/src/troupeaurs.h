#include <gtk/gtk.h>

typedef struct
{
	char identifiant[20];
	char sexe[10];
	int jour;
	int mois;
	int annee;
        char type[10];
}troupeau;

void ajouter(troupeau t);
int veriftroupeau(troupeau t);
void supprimertroupeau(troupeau t);
void modifiertroupeau(troupeau t);
void affichertroupeau(GtkWidget *treeview, char ch[]);
int nombreveau();
int nombrebrebi();
troupeau chercher(char r[20]);
