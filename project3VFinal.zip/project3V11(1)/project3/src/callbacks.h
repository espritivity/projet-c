#include <gtk/gtk.h>

void on_buttonaj_wadm_clicked(GtkButton *button,
                              gpointer user_data);

void on_buttonmod_wadm_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonabs_wadm_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonrech_wadm_clicked(GtkButton *button,
                                gpointer user_data);

void on_hraj_wadm_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data);

void on_fraj_wadm_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data);

void on_buttondcnx_wadm_clicked(GtkButton *button,
                                gpointer user_data);

void on_buttonvalaj_wadm_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonretaj_wadm_clicked(GtkButton *button,
                                 gpointer user_data);

void on_frmod_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_hrmod_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_lsadms_wadm_toggled(GtkToggleButton *togglebutton,
                            gpointer user_data);

void on_lsemp_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_lsouv_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_lsouv_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_lsemp_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_lsadms_wadm_toggled(GtkToggleButton *togglebutton,
                            gpointer user_data);

void on_hrmod_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_frmod_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_buttonvalmod_wadm_clicked(GtkButton *button,
                                  gpointer user_data);

void on_buttonretmod_wadm_clicked(GtkButton *button,
                                  gpointer user_data);

void on_buttonokmod_wadm_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonaff_wadm_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonret_wadm_clicked(GtkButton *button,
                               gpointer user_data);

void on_treeviewaff_wadm_row_activated(GtkTreeView *treeview,
                                       GtkTreePath *path,
                                       GtkTreeViewColumn *column,
                                       gpointer user_data);

void on_buttonafficher_wadm_clicked(GtkButton *button,
                                    gpointer user_data);

void on_buttonretaff_wadm_clicked(GtkButton *button,
                                  gpointer user_data);

void on_buttonsuppr_wadm_clicked(GtkButton *button,
                                 gpointer user_data);

void on_okbuttonsucc_wadm_clicked(GtkButton *button,
                                  gpointer user_data);

void on_buttonquit_clicked(GtkButton *button,
                           gpointer user_data);

void on_buttoncnx_clicked(GtkButton *button,
                          gpointer user_data);

void on_buttondcnx_ea_clicked(GtkButton *button,
                              gpointer user_data);

void on_buttongestion_ea_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonaj_wemp_clicked(GtkButton *button,
                              gpointer user_data);

void on_buttonaff_wemp_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonmod_wemp_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonrech_wemp_clicked(GtkButton *button,
                                gpointer user_data);

void on_buttonabs_wemp_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonvalaj_wemp_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonretaj_wemp_clicked(GtkButton *button,
                                 gpointer user_data);

void on_fraj_wemp_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data);

void on_hraj_wemp_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data);

void on_lsemp_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_lsouv_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_hrmod_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_frmod_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_buttonvalmod_wemp_clicked(GtkButton *button,
                                  gpointer user_data);

void on_buttonsuppr_wemp_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonokmod_wemp_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonretmod_wemp_clicked(GtkButton *button,
                                  gpointer user_data);

void on_buttonafficher_wemp_clicked(GtkButton *button,
                                    gpointer user_data);

void on_buttonretaff_wemp_clicked(GtkButton *button,
                                  gpointer user_data);

void on_treeviewaff_wemp_row_activated(GtkTreeView *treeview,
                                       GtkTreePath *path,
                                       GtkTreeViewColumn *column,
                                       gpointer user_data);

void on_buttondcnx_wemp_clicked(GtkButton *button,
                                gpointer user_data);

void on_buttonviewaj_wadm_toggled(GtkToggleButton *togglebutton,
                                  gpointer user_data);

void on_buttonviewmod_wadm_toggled(GtkToggleButton *togglebutton,
                                   gpointer user_data);

void on_buttonview_auth_toggled(GtkToggleButton *togglebutton,
                                gpointer user_data);

void on_buttonviewaj_wemp_toggled(GtkToggleButton *togglebutton,
                                  gpointer user_data);

void on_buttonviewmod_wemp_toggled(GtkToggleButton *togglebutton,
                                   gpointer user_data);

void on_buttontauxabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data);

void on_buttonmarqabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data);

void on_buttondcnxabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data);

void on_buttonretabs_wadm_clicked(GtkButton *button,
                                  gpointer user_data);

void on_lsemabs_wadm_toggled(GtkToggleButton *togglebutton,
                             gpointer user_data);

void on_lsouvabs_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data);

void on_abs_wadm_toggled(GtkToggleButton *togglebutton,
                         gpointer user_data);

void on_pres_wadm_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data);

void on_treeviewaffabs_wadm_row_activated(GtkTreeView *treeviewaffabs,
                                          GtkTreePath *path,
                                          GtkTreeViewColumn *column,
                                          gpointer user_data);

void on_buttonretaffabs_wadm_clicked(GtkButton *button,
                                     gpointer user_data);

void on_buttonvalafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data);

void on_buttonretafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data);

void on_buttondateabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data);

void on_lsemptabs_wadm_toggled(GtkToggleButton *togglebutton,
                               gpointer user_data);

void on_lsouvtabs_wadm_toggled(GtkToggleButton *togglebutton,
                               gpointer user_data);

void on_buttonafftabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data);

void on_buttonretafftabs_wadm_clicked(GtkButton *button,
                                      gpointer user_data);

void on_buttonafficherabs_wadm_clicked(GtkButton *button,
                                       gpointer user_data);

void on_buttonmodafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data);

void on_buttonsupafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data);

void on_buttonret_wemp_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttongcal_ee_clicked(GtkButton *button,
                              gpointer user_data);

void on_buttongequi_ee_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttongtroup_ee_clicked(GtkButton *button,
                                gpointer user_data);

void on_buttongutils_ee_clicked(GtkButton *button,
                                gpointer user_data);

void on_buttongclients_ee_clicked(GtkButton *button,
                                  gpointer user_data);

void on_buttongcapts_ee_clicked(GtkButton *button,
                                gpointer user_data);

void on_buttondcnx_ee_clicked(GtkButton *button,
                              gpointer user_data);

void on_buttonaffichabs_wadm_clicked(GtkButton *button,
                                     gpointer user_data);

void on_buttonemp_ea_clicked(GtkButton *button,
                             gpointer user_data);

void on_buttonret_gpl_clicked(GtkButton *button,
                              gpointer user_data);

void on_buttondcnx_gpl_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonactu_gpl_clicked(GtkButton *button,
                               gpointer user_data);

void on_treeviewpl_gpl_row_activated(GtkTreeView *treeviewpl,
                                     GtkTreePath *path,
                                     GtkTreeViewColumn *column,
                                     gpointer user_data);

void on_lraj_gpl_toggled(GtkToggleButton *togglebutton,
                         gpointer user_data);

void on_fraj_gpl_toggled(GtkToggleButton *togglebutton,
                         gpointer user_data);

void on_buttonrejat_gpl_clicked(GtkButton *button,
                                gpointer user_data);

void on_buttonvalaj_gpl_clicked(GtkButton *button,
                                gpointer user_data);

void on_frmod_gpl_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data);

void on_lrmod_gpl_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data);

void on_buttonokmod_gpl_clicked(GtkButton *button,
                                gpointer user_data);

void on_buttonvalmod_gpl_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonvalsup_gpl_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonretmod_gpl_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonrech_gpl_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonaj_gpl_clicked(GtkButton *button,
                             gpointer user_data);

void on_buttonmodsup_gpl_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonret_gpl_clicked(GtkButton *button,
                              gpointer user_data);

void on_buttonaff_gpl_clicked(GtkButton *button,
                              gpointer user_data);

void on_buttoncal_gpl_clicked(GtkButton *button,
                              gpointer user_data);

void on_buttonretaff_gpl_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonrechabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data);
void
on_checkouv_wadm_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkemp_wadm_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkadm_wadm_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkouv_wemp_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkemp_wemp_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkempabs_wadm_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkouvabs_wadm_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
//-------gestionCapteurs------------------------------------------------//
void
on_buttonAjouterCapteur_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonModifierCapteur_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonSupprimerCapteur_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonConsulterCapteur_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonRechercherCapteur_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonModifierVerifier_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonModifierCapteur_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonModifierVerifier_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonAlerteTemperature_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonAlerteFiable_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonAlerteAttention_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAlerteHumidite_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonAlerteDanger_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonAlerteCapteur_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonDonAjoCap_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonConsulterDonnee_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewListeCapteurs_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeviewListeDonnees_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonQuitter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAct1MES_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAct2MES_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonQuitterCap_clicked            (GtkButton       *button,
                                        gpointer         user_data);
void
on_buttonAjouterWBF_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonModifierWBF_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonSupprimerWBF_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonConsulterWBF_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonRechercherWBF_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonModifierVerifierWBF_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonModifierWBF_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonModifierVerifierWBF_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_labelModifierWBF_activate_current_link
                                        (GtkLabel        *label,
                                        gpointer         user_data);

gboolean
on_labelModifierWBF_button_press_event (GtkWidget       *widget,
                                        GdkEventButton  *event,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonFermerTreeWBF_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonModifierAfficherWBF_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonRetourTreeWBF_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewListeEquipements_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonUpdateWBF_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonTypeProduitWBF_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonTypeMaterielWBF_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonTypeMachineWBF_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonTypeVeheculeWBF_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonDeconexionWBF_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonRetourMenuWBF_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbuttonReussieWBF_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbuttonExisteWBF_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajoutertroupeaux_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttoncherchertroupeaux_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaodifiertroupeaux_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsupprimertroupeaux_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonmalletroupeaux_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonfemelletroupeaux_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonretourajouttroupeau_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajoutconfirmertroupeaux_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffichertroupeau_clicked      (GtkButton       *button,
                                        gpointer         user_data);


void
on_retouraffichagetroupeau_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttoncherchertroupeaux_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifieraffichertroupeau_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_supptroupeau_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_retouraffichagetroupeau_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewveau_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeviewbrebi_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonaffichertroupeau_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifieraffichertroupeau_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_supptroupeau_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonfemellemodifier_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonmodifiermale_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonmodifiertroupeau_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonretoursuccestroupeau_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_terminersuccestroupeau_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonretourinittroupeau_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonretoursucces2troupeau_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_nombretroupeau_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_retournombretroupeaux_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_retoursuccesmodifiertroupeau_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);
void
on_buttonModifier_Supprimer_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonClientFidele_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAjouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAfficher_Supprimer_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_AjouterValider_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_AjouterRetour_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierRetour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_TreeviewAfficher_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_AfficherRechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_SuccValider_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_ButtonOnView_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_AuthConnexion_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_AuthQuitter_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonokmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);



void
on_buttonAfficher_rechercher_clicked   (GtkButton       *button,
                                        gpointer         user_data);


void
on_afficherretour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonDeconneter_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_affichercf_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_recherchecf_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffichercf_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajoutercf_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourcf_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourclientfidele_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_show_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiserr_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourgc_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAfficherdefectWBF_clicked     (GtkButton       *button,
                                        gpointer         user_data);
