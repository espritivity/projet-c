#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "equipement.h"
#include <gtk/gtk.h>

enum
{
    REF,
    NOM,
    MARQ,
    TYPE,
    QUANT,
    COLUMNS
};

void ajouter_e(Equi E)
{
    FILE *f;
    f = fopen("equipement.txt", "a+");
    if (f != NULL)
    {
        fprintf(f, "%s %s %d %s %s\n", E.ref, E.nom, E.quant, E.type, E.marq);
    }
    fclose(f);
}

void supprimer_e(char ref[20])
{
    Equi E;
    FILE * f1=NULL,* f=NULL;
    int test;
    test=verifier_refe(ref);
    if (test==0)
    {
        printf("ce refernce n existe pas \n");
    }
    else
    {
        f=fopen("equipement.txt","r"); 
        f1=fopen("temp.txt","w"); 
        if (f!=NULL)
        {
            while (fscanf(f,"%s %s %d %s %s\n", E.ref, E.nom, &E.quant, E.type, E.marq)!=EOF)  
            {     
                if (f1!=NULL) 
                {	
                    if (strcmp(E.ref,ref)!=0)  
                        fprintf(f1,"%s %s %d %s %s\n", E.ref, E.nom, E.quant, E.type, E.marq);
                }       
                else if (f1 == NULL ) 
                    printf("ERROR");
                }           	
            }
        else if (f==NULL )
        { 
            printf("ERROR ");
        }
        fclose(f);
        fclose(f1);
        remove("equipement.txt");
        rename("temp.txt","equipement.txt");
    }
    
    
}

void modifier_e(Equi M){
    Equi E;
    FILE * f1=NULL,* f=NULL;
    f=fopen("equipement.txt","r"); 
    f1=fopen("temp.txt","w"); 
    if (f!=NULL)
    {
        while (fscanf(f,"%s %s %d %s %s\n", E.ref, E.nom, &E.quant, E.type, E.marq)!=EOF)  
        {     
            if (f1!=NULL) 
            {	
                if (strcmp(E.ref,M.ref)!=0)
                {
                    fprintf(f1,"%s %s %d %s %s\n", E.ref, E.nom, E.quant, E.type, E.marq);
                }  
                else
                {
                    fprintf(f1,"%s %s %d %s %s\n", M.ref, M.nom, M.quant, M.type, M.marq);
                }
                    
            }       
            else if (f1 == NULL ) 
                printf("ERROR");
        }           	
    }
    else if (f==NULL )
    { 
        printf("ERROR ");
    }
    fclose(f);
    fclose(f1);
    remove("equipement.txt");
    rename("temp.txt","equipement.txt");
}

Equi rechercher_e(char ref[20])
{
    FILE * f=NULL;
    Equi E;
    f=fopen("equipement.txt","a+");
    if (f!=NULL)
    {
        while (fscanf(f,"%s %s %d %s %s\n", E.ref, E.nom, &E.quant, E.type, E.marq)!=EOF)  
        {	
            if((strcmp(ref,E.ref)==0))
            {
                return E;
            }
        }
    }
    fclose(f);
}

int verifier_refe(char ref[20])
{
    FILE * f=NULL;
    f=fopen("equipement.txt","r");
    Equi E;
    int test=0;
    if (f!=NULL)
    {
        while (fscanf(f,"%s %s %d %s %s\n", E.ref, E.nom, &E.quant, E.type, E.marq)!=EOF)  
        {	
            if((strcmp(ref,E.ref)==0))
            {
                test=1;
                break;
            }
        }
    }
    fclose(f);
    return(test);
}

void consulter_e(GtkWidget *liste)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;

    char ref[20];
    char nom[20];
    char marq[20];
    char type[20];
    char quant[20];
    gtk_list_store_clear(liste);
    FILE *f=NULL;
    store=gtk_tree_view_get_model(liste);
    if (store==NULL)
    {
        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" reference",renderer,"text",REF,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" Nom",renderer,"text",NOM,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" Marque",renderer,"text",MARQ,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" Type",renderer,"text",TYPE,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" Quantites",renderer,"text",QUANT,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
        store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
        f=fopen("equipement.txt","r");
        if(f==NULL)
        {
            return;
        }
        else
        {
            //f=fopen("equipement.txt","a+");
            while (fscanf(f,"%s %s %s %s %s\n", ref, nom, quant,type,marq)!=EOF)
            {
                gtk_list_store_append(store,&iter);
                gtk_list_store_set(store,&iter,REF,ref,NOM,nom,QUANT,quant,TYPE,type,MARQ,marq,-1);
            }
            //fclose(f);
            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
            g_object_unref(store);
            
        }
        fclose(f);
    }
}