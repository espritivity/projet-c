#ifndef CLIENT_H_
#define CLIENT_H_
#include <stdio.h>
#include <gtk/gtk.h>

typedef struct
{
    char nom[50];
    char prenom[50];
    char nationalite[50];
    char sexe[50];
    char cin[50];
    char prix[50];

} CLIENT;
///////////////////////CONTROLE DE SAISIE////////////////
int verifCin(char cin[]);
int rechLigne(char cin[], char fich[]);
void suppEspaces(char chaine[]);
int verifClient(char cin[], char fich[]);
///////////////////////CRUD/////////////////////
void ajoutClient(CLIENT u, char fich[]);
void modifierclient(CLIENT u,char cin[]);
void supprimer(char cin[]);
void rechClient(GtkWidget *TreeviewAfficher);
void affClient(GtkWidget *treeview, char fich[]);
void ajouterclientfid(CLIENT a, char fich[]);
CLIENT recheClient(char cin[]);











#endif


