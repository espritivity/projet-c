#ifndef GESTIONUTILS_H_
#define GESTIONUTILS_H_
#include <stdio.h>
#include <gtk/gtk.h>

typedef struct
{
    int jour, mois, annee;

} DATE;
typedef struct
{
    char cin[50];
    char pw[50];

} LOGIN;

typedef struct
{
    LOGIN log;
    char nom[50];
    char prenom[50];
    char dateNaiss[50];
    char numTel[50];
    char sexe[50];
    char role[50];
    DATE date;

} UTILISATEUR;

typedef struct
{
    DATE dateAbs;
    LOGIN logAbs;
    char valAbs[20];
    char roleAbs[20];
    char date[100];
    char jtrav[20];
    char jabs[20];
    char taux[20];
    int ctot, cabs;
} OUVRIER;

//Prototypes des fonctions
///1ere tache
////controle de saisie
int verifCin(char cin[]);
int verifNum(char num[]);
int rechLigne(char cin[], char fich[]);
void suppEspaces(char chaine[]);
int verifUtils(char cin[], char fich[]);
////CRUD
void ajoutUtils(UTILISATEUR u, char fich[]);
void modifUtils(UTILISATEUR m, char cin[], char fich[]);
void suppUtils(char cin[], char fich[]);
UTILISATEUR rechUtils(char cin[], char fich[]);
void affUtils(GtkWidget *treeview, char fich[]);

/*2eme tache*/
OUVRIER dateAuj(OUVRIER o);
void marquerAbs(OUVRIER o, char fich[]);
void modifAbs(OUVRIER m, char cin[], char fich[]);
void suppAbs(char cin[], char dt[], char fich[]);
void tauxAbs(char fich1[], char fich2[]);
OUVRIER calcAbs(char cinn[], char dtd[], char dtf[], char fich[]);
void affAbs(GtkWidget *treeviewaffabs, char fich[]);

#endif