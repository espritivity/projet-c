#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "capteur.h"
#include <gtk/gtk.h>
enum
{
    REFf,
    TYPE,
    EMP,
    MARQ,
    ETAT,
    COLUMNS
};
enum
{
    REF,
    MARQUE,
    JOUR,
    MOIS,
    ANNEE,
    VALEUR,
    COLUMN
};

void ajouter_donnee(don d)
{
    FILE *f;
    f = fopen("donnee.txt", "a+");
    if (f != NULL)
    {
        fprintf(f, "%s %s %d %d %d %d\n", d.ref,d.marque, d.jour, d.mois + 1, d.annee, d.valeur); 
    }
    fclose(f);
}

void ajouter_capteur(cap c)
{
    FILE *f;
    f = fopen("capteur.txt", "a+");
    if (f != NULL)
    {
        fprintf(f, "%s %s %s %s %d\n", c.ref, c.type, c.emp, c.marq, c.etat);
    }
    fclose(f);
}

void supprimer_capteur(char ref[20])
{
    cap c;
    FILE * f1=NULL,* f=NULL;
    int test;
    test=verifier_ref(ref);
    if (test==0)
    {
        printf("cette refernce est inexistante \n");
    }
    else
    {
        f=fopen("capteur.txt","r");
        f1=fopen("temp.txt","w"); 
        if (f!=NULL)
        {
            while (fscanf(f,"%s %s %s %s %d\n", c.ref, c.type, c.emp, c.marq, &c.etat)!=EOF)  
            {     
                if (f1!=NULL) 
                {	
                    if (strcmp(c.ref,ref)!=0)  
                        fprintf(f1,"%s %s %s %s %d\n", c.ref, c.type, c.emp, c.marq, c.etat);
                }       
                else if (f1 == NULL ) 
                    printf("ERROR");
                }           	
            }
        else if (f==NULL )
        { 
            printf("ERROR ");
        }
        fclose(f);
        fclose(f1);
        remove("capteur.txt");
        rename("temp.txt","capteur.txt");
    }  
}

void supprimer_donneeCapteur(char ref[20])
{
    don d;
    FILE * f1=NULL,* f=NULL;
    int test;

        f=fopen("donnee.txt","r");
        f1=fopen("temp.txt","w"); 
        if (f!=NULL)
        {
            while (fscanf(f,"%s %s %d %d %d %d\n", d.ref,d.marque, &d.jour, &d.mois, &d.annee, &d.valeur)!=EOF)  
            {     
                if (f1!=NULL) 
                {	
                    if (strcmp(d.ref,ref)!=0)  

                        fprintf(f1,"%s %s %d %d %d %d\n", d.ref, d.marque, d.jour, d.mois, d.annee, d.valeur);
                }       
                else if (f1 == NULL ) 
                    printf("ERROR");
                }           	
            }
        else if (f==NULL )
        { 
            printf("ERROR ");
        }
        fclose(f);
        fclose(f1);
        remove("donnee.txt");
        rename("temp.txt","donnee.txt");
     
}

void modifier_capteur(cap c){
    cap ca;
    FILE * f1=NULL,* f=NULL;
    f=fopen("capteur.txt","r"); 
    f1=fopen("temp.txt","w"); 
    if (f!=NULL)
    {
        while (fscanf(f,"%s %s %s %s %d\n", ca.ref, ca.type, ca.emp, ca.marq, &ca.etat)!=EOF)  
        {     
            if (f1!=NULL) 
            {	
                if (strcmp(c.ref,ca.ref)==0)
                {
		fprintf(f1,"%s %s %s %s %d\n", c.ref, c.type, c.emp, c.marq, c.etat);                                       
                }  
                else
                {

		 fprintf(f1,"%s %s %s %s %d\n", ca.ref, ca.type, ca.emp, ca.marq, ca.etat);   
                }
                    
            }       
            else if (f1 == NULL ) 
                printf("ERROR");
        }           	
    }
    else if (f==NULL )
    { 
        printf("ERROR ");
    }
    fclose(f);
    fclose(f1);
    remove("capteur.txt");
    rename("temp.txt","capteur.txt");
}

cap rechercher_capteur(char ref[20])
{
    FILE * f=NULL;
    cap c;
    f=fopen("capteur.txt","a+");
    if (f!=NULL)
    {
        while (fscanf(f,"%s %s %s %s %d\n", c.ref, c.type, c.emp, c.marq, &c.etat)!=EOF)  
        {	
            if((strcmp(ref,c.ref)==0))
            {
                return c;
            }
        }
    }
    fclose(f); 
}
int verifier_ref(char ref[20])
{
    FILE * f=NULL;
    f=fopen("capteur.txt","r");
    cap c;
    int test=0;
    if (f!=NULL)
    {
        while (fscanf(f,"%s %s %s %s %d\n", c.ref, c.type, c.emp, c.marq, &c.etat)!=EOF)  
        {	
            if((strcmp(ref,c.ref)==0))
            {
                test=1;
                break;
            }
        }
    }
    fclose(f);
    return(test);
}

void consulter_capteur(GtkWidget *treeviewListeCapteurs)
{
    cap c;
   GtkCellRenderer *renderer;
   GtkTreeViewColumn *column;
   GtkTreeIter iter;
   GtkListStore *store;

   gtk_list_store_clear(treeviewListeCapteurs);
   FILE *f = NULL;
   store = gtk_tree_view_get_model(treeviewListeCapteurs);
   if (store == NULL)
   {
      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" REFERENCE", renderer, "text", REFf, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewListeCapteurs), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" TYPE", renderer, "text", TYPE, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewListeCapteurs), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" EMPLACEMENT", renderer, "text", EMP, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewListeCapteurs), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" MARQ", renderer, "text", MARQ, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewListeCapteurs), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" ETAT", renderer, "text", ETAT, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewListeCapteurs), column);
   }
   store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT);
   f = fopen("capteur.txt", "r");
   if (f == NULL)
   {
      return;
   }
   else
   {
      f = fopen("capteur.txt", "a+");
      while (fscanf(f, "%s %s %s %s %d\n", c.ref, c.type, c.emp, c.marq, &c.etat) != EOF)
      {
         gtk_list_store_append(store, &iter);
         gtk_list_store_set(store, &iter, REFf, c.ref, TYPE, c.type, EMP, c.emp, MARQ, c.marq, ETAT, c.etat, -1);
      }
      //fclose(f);
      gtk_tree_view_set_model(GTK_TREE_VIEW(treeviewListeCapteurs), GTK_TREE_MODEL(store));
      g_object_unref(store);
   }
   fclose(f);

}

void consulter_donnee(GtkWidget *treeviewListeDonnees)
{
don d;
   GtkCellRenderer *renderer;
   GtkTreeViewColumn *column;
   GtkTreeIter iter;
   GtkListStore *store;

   gtk_list_store_clear(treeviewListeDonnees);
   FILE *f = NULL;
   store = gtk_tree_view_get_model(treeviewListeDonnees);
   if (store == NULL)
   {
      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" REFERENCE", renderer, "text", REF, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewListeDonnees), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" MARQUE", renderer, "text", MARQUE, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewListeDonnees), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" JOUR", renderer, "text", JOUR, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewListeDonnees), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" MOIS", renderer, "text", MOIS, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewListeDonnees), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" ANNEE", renderer, "text", ANNEE, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewListeDonnees), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" VALEUR", renderer, "text", VALEUR, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewListeDonnees), column);
   }
   store = gtk_list_store_new(COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);
   f = fopen("donnee.txt", "r");
   if (f == NULL)
   {
      return;
   }
   else
   {
      f = fopen("donnee.txt", "a+");
      while (fscanf(f, "%s %s %d %d %d %d\n", d.ref, d.marque, &d.jour, &d.mois, &d.annee, &d.valeur) != EOF)
      {
         gtk_list_store_append(store, &iter);
         gtk_list_store_set(store, &iter, REF, d.ref, MARQUE, d.marque, JOUR, d.jour, MOIS, d.mois, ANNEE, d.annee, VALEUR, d.valeur, -1);
      }
      //fclose(f);
      gtk_tree_view_set_model(GTK_TREE_VIEW(treeviewListeDonnees), GTK_TREE_MODEL(store));
      g_object_unref(store);
   }
   fclose(f);
} 

/*void alerte_capteur();
{*/


