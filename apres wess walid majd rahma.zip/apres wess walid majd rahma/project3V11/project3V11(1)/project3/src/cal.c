void on_AjouterClient_clicked(GtkButton *button,
                              gpointer user_data)
{
    client c;
    GtkWidget *entryNom;
    GtkWidget *entryCin;
    GtkWidget *entryPrenom;
    GtkWidget *entryAdresse;
    GtkWidget *entryNumtel;
    GtkWidget *entryNationalite;
    GtkWidget *labelCin;
    GtkWidget *labelnom;
    GtkWidget *labelprenom;
    GtkWidget *labeladresse;
    GtkWidget *labelnumtel;
    GtkWidget *labelnationalite;
    GtkWidget *existe;
    GtkWidget *success;
    GtkWidget *cal;
    int b = 1;
    int jj, mm, aa;

    FILE *f = NULL;

    entryCin = lookup_widget(gestion, "entry5");
    entryNom = lookup_widget(gestion, "entry1");
    entryPrenom = lookup_widget(gestion, "entry2");
    entryAdresse = lookup_widget(gestion, "entry4");
    entryNumtel = lookup_widget(gestion, "entry3");
    entryNationalite = lookup_widget(gestion, "combobox1");
    labelCin = lookup_widget(gestion, "label13");
    labelnom = lookup_widget(gestion, "label7");
    labelprenom = lookup_widget(gestion, "label8");
    labeladresse = lookup_widget(gestion, "label9");
    labelnumtel = lookup_widget(gestion, "label10");
    labelnationalite = lookup_widget(gestion, "nat6");
    existe = lookup_widget(gestion, "label34");
    success = lookup_widget(gestion, "label35");
    cal = lookup_widget(gestion, "calendar1");
    strcpy(c.cin, gtk_entry_get_text(GTK_ENTRY(entryCin)));
    strcpy(c.nom, gtk_entry_get_text(GTK_ENTRY(entryNom)));
    strcpy(c.prenom, gtk_entry_get_text(GTK_ENTRY(entryPrenom)));
    strcpy(c.adresse, gtk_entry_get_text(GTK_ENTRY(entryAdresse)));
    strcpy(c.numtel, gtk_entry_get_text(GTK_ENTRY(entryNumtel)));
    strcpy(c.nationalite, gtk_combo_box_get_active_text(GTK_COMBO_BOX(entryNationalite)));

    gtk_calendar_get_date(GTK_CALENDAR(cal), &aa, &mm, &jj);
    gtk_widget_hide(success);

    // controle saisie
    if (strcmp(c.cin, "") == 0)
    {
        gtk_widget_show(labelCin);
        b = 0;
    }
    else
    {
        gtk_widget_hide(labelCin);
    }

    if (strcmp(c.nom, "") == 0)
    {
        gtk_widget_show(labelnom);
        b = 0;
    }
    else
    {
        gtk_widget_hide(labelnom);
    }
    if (strcmp(c.prenom, "") == 0)
    {
        gtk_widget_show(labelprenom);
        b = 0;
    }
    else
    {
        gtk_widget_hide(labelprenom);
    }
    if (strcmp(c.adresse, "") == 0)
    {
        gtk_widget_show(labeladresse);
        b = 0;
    }
    else
    {
        gtk_widget_hide(labeladresse);
    }
    if (strcmp(c.numtel, "") == 0)
    {
        gtk_widget_show(labelnumtel);
        b = 0;
    }
    else
    {
        gtk_widget_hide(labelnumtel);
    }

    if (b == 1)
    {

        if (exist_client(c.cin) == 1)
        {

            gtk_widget_show(existe);
        }

        else
        {
            gtk_widget_hide(existe);

            f = fopen("clients.txt", "a+");
            fprintf(f, "%s %s %s %s %s %s %s %d/%d/%d \n", c.cin, c.nom, c.prenom, c.adresse, c.numtel, c.nationalite, c.date, jj, mm + 1, aa);
            fclose(f);
            //ajouter_client(c);

            gtk_widget_show(success);

            //mise a jour du treeView
            GtkWidget *p = lookup_widget(gestion, "treeview2");

            AfficherClient(p, "clients.txt");
        }
    }
}